package com.somsakelect.android.mqttcontrolapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.somsakelect.android.mqtt.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;

public class StartTresAtuad extends AppCompatActivity {

    private Handler handler;
    private boolean isRunning = true;
    private boolean voltarInicioSTA = false;
    private boolean avcA_STA1 = false, recA_STA1 = false, avcB_STA1 = false, recB_STA1 = false, avcC_STA1 = false, recC_STA1 = false; // Sequência 1: A+ B+ C+ C- B- A-
    private boolean avcA_STA1_2v = false, recA_STA1_2v = false, avcB_STA1_2v = false, recB_STA1_2v = false, avcC_STA1_2v = false, recC_STA1_2v = false;
    private boolean avcA_STA1_3v = false, recA_STA1_3v = false, avcB_STA1_3v = false, recB_STA1_3v = false, avcC_STA1_3v = false, recC_STA1_3v = false;
    private boolean avcA_STA1_4v = false, recA_STA1_4v = false, avcB_STA1_4v = false, recB_STA1_4v = false, avcC_STA1_4v = false, recC_STA1_4v = false;
    private boolean avcA_STA1_5v = false, recA_STA1_5v = false, avcB_STA1_5v = false, recB_STA1_5v = false, avcC_STA1_5v = false, recC_STA1_5v = false;
    private boolean avcA_STA1_6v = false, recA_STA1_6v = false, avcB_STA1_6v = false, recB_STA1_6v = false, avcC_STA1_6v = false, recC_STA1_6v = false;
    private boolean avcA_STA1_7v = false, recA_STA1_7v = false, avcB_STA1_7v = false, recB_STA1_7v = false, avcC_STA1_7v = false, recC_STA1_7v = false;
    private boolean avcA_STA1_8v = false, recA_STA1_8v = false, avcB_STA1_8v = false, recB_STA1_8v = false, avcC_STA1_8v = false, recC_STA1_8v = false;
    private boolean avcA_STA1_9v = false, recA_STA1_9v = false, avcB_STA1_9v = false, recB_STA1_9v = false, avcC_STA1_9v = false, recC_STA1_9v = false;
    private boolean avcA_STA1_10v = false, recA_STA1_10v = false, avcB_STA1_10v = false, recB_STA1_10v = false, avcC_STA1_10v = false, recC_STA1_10v = false;

    private MqttAndroidClient mqtt;

    private TextView statusConexaoSTA, seq_iniciadaSTA, aguard_concSTA;
    private ImageView gifA, gifB, gifC;
    private EditText numCiclosSTA;
    private String sensorASTA, sensorBSTA, sensorCSTA;
    private LinearLayout btnConectarSTA;
    private static final String TAG = "StartTresAtuad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_start_tres_atuad);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        handler = new Handler(Looper.getMainLooper());

        handler.post(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        });

        // Recupere o valor da string (HOST) do Intent
        final String MQTT_HOST = getIntent().getStringExtra("MQTTBROKERTA");
        final int MQTT_PORT = 1883;
        final String MQTT_URL = "tcp://" + MQTT_HOST + ":" + MQTT_PORT;
        final String MQTT_ID = getIntent().getStringExtra("MQTTIDTA");

        statusConexaoSTA = findViewById(R.id.tv_statusConexaoSTA);
        numCiclosSTA = findViewById(R.id.numCiclosSTA_e);
        btnConectarSTA = (LinearLayout) findViewById(R.id.ll_btnConectarSTA) ;
        btnConectarSTA.setVisibility(View.INVISIBLE);

        //MQTT
        mqtt = new MqttAndroidClient(this, MQTT_URL, MQTT_ID);
        mqtt.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.w(TAG, "Reconexão MQTT..." + reconnect);
                statusConexaoSTA.setText(reconnect ? "Reconectando..." : "Conectado!");
                if (mqtt.isConnected()) {
                    String tsx = "CONECTADO!";
                    statusConexaoSTA.setText(tsx);
                    btnConectarSTA.setVisibility(View.INVISIBLE);
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                if (cause != null) {
                    Log.e(TAG, "Conexão MQTT perdida..." + cause.getMessage());
                    String st = "Conexão perdida! " + cause.getMessage();
                    statusConexaoSTA.setText(st);
                    btnConectarSTA.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                if (topic.equals("/estado/atuadorA")) {
                    //String sensorA;
                    sensorASTA = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorA", sensorASTA);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorB")) {
                    //String sensorB;
                    sensorBSTA = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorB", sensorBSTA);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorC")) {
                    //String sensorC;
                    sensorCSTA = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorC", sensorCSTA);
                    Log.w(TAG, log);
                    //Debug
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.w(TAG, "Publish success...");
                //showToast("Publish success!");
            }
        });

        //Botão Conectar
        findViewById(R.id.conBrokerStartTresAtuad_btn).setOnClickListener(v -> connectMQTT());

        //Botão Voltar
        findViewById(R.id.voltarStartTresAtuad_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crie um Intent para iniciar MainActivity
                Intent mqtt_setup = new Intent(StartTresAtuad.this, MainActivity.class);
                disconnectMQTT();
                // Inicie a MainActivity com o Intent
                startActivity(mqtt_setup);
            }
        });

        //Botão Start
        findViewById(R.id.iniciaStartTresAtuad_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int nciclosSTA = 0;
                    nciclosSTA = Integer.parseInt(numCiclosSTA.getText().toString());

                    if (nciclosSTA > 10 || nciclosSTA < 1) {
                        numCiclosSTA.setError("Apenas números de 1 a 10.");
                        numCiclosSTA.requestFocus();
                    } else {
                        if (nciclosSTA == 1) {
                            IniciaSTAUmaVez();
                        }
                        if (nciclosSTA == 2) {
                            IniciaSTADuasVezes();
                        }
                        if (nciclosSTA == 3) {
                            IniciaSTATresVezes();
                        }
                        if (nciclosSTA == 4) {
                            IniciaSTAQuatroVezes();
                        }
                        if (nciclosSTA == 5) {
                            IniciaSTACincoVezes();
                        }
                        if (nciclosSTA == 6) {
                            IniciaSTASeisVezes();
                        }
                        if (nciclosSTA == 7) {
                            IniciaSTASeteVezes();
                        }
                        if (nciclosSTA == 8) {
                            IniciaSTAOitoVezes();
                        }
                        if (nciclosSTA == 9) {
                            IniciaSTANoveVezes();
                        }
                        if (nciclosSTA == 10) {
                            IniciaSTADezVezes();
                        }
                    }
                } catch (Exception e) {
                    numCiclosSTA.setError("Digite um número!");
                    numCiclosSTA.requestFocus();
                }
            }
        });
        //Try connect
        connectMQTT();
    }

    public void loop() {
        // Atuadores A, B e C estão recuados
        if (Objects.equals(sensorASTA, "Atuador A Recuado") && Objects.equals(sensorBSTA, "Atuador B Recuado") && Objects.equals(sensorCSTA, "Atuador C Recuado")) {
            // Condições para ciclo único
            if (avcA_STA1) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1 = false;
                avcB_STA1 = true;
            }

            // Condições para dois ciclos
            if (avcA_STA1_2v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_2v = false;
                avcB_STA1_2v = true;
            }

            // Condições para três ciclos
            if (avcA_STA1_3v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_3v = false;
                avcB_STA1_3v = true;
            }

            // Condições para quatro ciclos
            if (avcA_STA1_4v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_4v = false;
                avcB_STA1_4v = true;
            }

            // Condições para cinco ciclos
            if (avcA_STA1_5v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_5v = false;
                avcB_STA1_5v = true;
            }

            // Condições para seis ciclos
            if (avcA_STA1_6v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_6v = false;
                avcB_STA1_6v = true;
            }

            // Condições para sete ciclos
            if (avcA_STA1_7v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_7v = false;
                avcB_STA1_7v = true;
            }

            // Condições para oito ciclos
            if (avcA_STA1_8v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_8v = false;
                avcB_STA1_8v = true;
            }

            // Condições para nove ciclos
            if (avcA_STA1_9v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_9v = false;
                avcB_STA1_9v = true;
            }

            // Condições para dez ciclos
            if (avcA_STA1_10v) {
                publishAmais();
                aguard_concSTA.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcA_STA1_10v = false;
                avcB_STA1_10v = true;
            }

            // Finalizando sequência e voltando para tela inicial
            if (voltarInicioSTA) {
                voltarInicioSTA = false;
                // Crie um Intent para iniciar MainActivity
                Intent mqtt_setup = new Intent(StartTresAtuad.this, MainActivity.class);
                disconnectMQTT();
                // Inicie a MainActivity com o Intent
                startActivity(mqtt_setup);
            }
        }
        // Atuador A está avançado e Atuadores B e C estão recuados
        if (Objects.equals(sensorASTA, "Atuador A Avançado") && Objects.equals(sensorBSTA, "Atuador B Recuado") && Objects.equals(sensorCSTA, "Atuador C Recuado")) {
            // Condições para ciclo único
            if (avcB_STA1) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1 = false;
                avcC_STA1 = true;
            }
            if (recA_STA1) {
                publishAmenos();
                seq_iniciadaSTA.setText(R.string.seqFinalizando);
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1 = false;
                // Fim da sequência onDestroy();
                voltarInicioSTA = true;
            }
            // Condições para dois ciclos
            if (avcB_STA1_2v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_2v = false;
                avcC_STA1_2v = true;
            }
            if (recA_STA1_2v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_2v = false;
                // Inicia ciclo único da sequência 1
                avcA_STA1 = true;
            }
            // Condições para três ciclos
            if (avcB_STA1_3v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_3v = false;
                avcC_STA1_3v = true;
            }
            if (recA_STA1_3v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_3v = false;
                // Inicia dois ciclos da sequência 1
                avcA_STA1_2v = true;
            }
            // Condições para quatro ciclos
            if (avcB_STA1_4v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_4v = false;
                avcC_STA1_4v = true;
            }
            if (recA_STA1_4v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_4v = false;
                // Inicia três ciclos da sequência 1
                avcA_STA1_3v = true;
            }
            // Condições para cinco ciclos
            if (avcB_STA1_5v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_5v = false;
                avcC_STA1_5v = true;
            }
            if (recA_STA1_5v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_5v = false;
                // Inicia quatro ciclos da sequência 1
                avcA_STA1_4v = true;
            }
            // Condições para seis ciclos
            if (avcB_STA1_6v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_6v = false;
                avcC_STA1_6v = true;
            }
            if (recA_STA1_6v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_6v = false;
                // Inicia cinco ciclos da sequência 1
                avcA_STA1_5v = true;
            }
            // Condições para sete ciclos
            if (avcB_STA1_7v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_7v = false;
                avcC_STA1_7v = true;
            }
            if (recA_STA1_7v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_7v = false;
                // Inicia seis ciclos da sequência 1
                avcA_STA1_6v = true;
            }
            // Condições para oito ciclos
            if (avcB_STA1_8v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_8v = false;
                avcC_STA1_8v = true;
            }
            if (recA_STA1_8v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_8v = false;
                // Inicia sete ciclos da sequência 1
                avcA_STA1_7v = true;
            }
            // Condições para nove ciclos
            if (avcB_STA1_9v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_9v = false;
                avcC_STA1_9v = true;
            }
            if (recA_STA1_9v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_9v = false;
                // Inicia oito ciclos da sequência 1
                avcA_STA1_8v = true;
            }
            // Condições para dez ciclos
            if (avcB_STA1_10v) {
                publishBmais();
                aguard_concSTA.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                avcB_STA1_10v = false;
                avcC_STA1_10v = true;
            }
            if (recA_STA1_10v) {
                publishAmenos();
                aguard_concSTA.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recA_STA1_10v = false;
                // Inicia nove ciclos da sequência 1
                avcA_STA1_9v = true;
            }
        }
        // Atuadores A e B estão avançados e Atuador C está recuado
        if (Objects.equals(sensorASTA, "Atuador A Avançado") && Objects.equals(sensorBSTA, "Atuador B Avançado") && Objects.equals(sensorCSTA, "Atuador C Recuado")) {
            // Condições para ciclo único
            if (avcC_STA1) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1 = false;
                recC_STA1 = true;
            }
            if (recB_STA1) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1 = false;
                recA_STA1 = true;
            }
            // Condições para dois ciclos
            if (avcC_STA1_2v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_2v = false;
                recC_STA1_2v = true;
            }
            if (recB_STA1_2v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_2v = false;
                recA_STA1_2v = true;
            }
            // Condições para três ciclos
            if (avcC_STA1_3v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_3v = false;
                recC_STA1_3v = true;
            }
            if (recB_STA1_3v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_3v = false;
                recA_STA1_3v = true;
            }
            // Condições para quatro ciclos
            if (avcC_STA1_4v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_4v = false;
                recC_STA1_4v = true;
            }
            if (recB_STA1_4v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_4v = false;
                recA_STA1_4v = true;
            }
            // Condições para cinco ciclos
            if (avcC_STA1_5v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_5v = false;
                recC_STA1_5v = true;
            }
            if (recB_STA1_5v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_5v = false;
                recA_STA1_5v = true;
            }
            // Condições para seis ciclos
            if (avcC_STA1_6v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_6v = false;
                recC_STA1_6v = true;
            }
            if (recB_STA1_6v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_6v = false;
                recA_STA1_6v = true;
            }
            // Condições para sete ciclos
            if (avcC_STA1_7v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_7v = false;
                recC_STA1_7v = true;
            }
            if (recB_STA1_7v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_7v = false;
                recA_STA1_7v = true;
            }
            // Condições para oito ciclos
            if (avcC_STA1_8v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_8v = false;
                recC_STA1_8v = true;
            }
            if (recB_STA1_8v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_8v = false;
                recA_STA1_8v = true;
            }
            // Condições para nove ciclos
            if (avcC_STA1_9v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_9v = false;
                recC_STA1_9v = true;
            }
            if (recB_STA1_9v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_9v = false;
                recA_STA1_9v = true;
            }
            // Condições para dez ciclos
            if (avcC_STA1_10v) {
                publishCmais();
                aguard_concSTA.setText(R.string.avancandoC);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                gifC.setImageResource(R.drawable.gif_avancando_c);
                avcC_STA1_10v = false;
                recC_STA1_10v = true;
            }
            if (recB_STA1_10v) {
                publishBmenos();
                aguard_concSTA.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                gifC.setImageResource(R.drawable.atuador_c_recuado);
                recB_STA1_10v = false;
                recA_STA1_10v = true;
            }
        }
        // Atuadores A, B e C estão avançados
        if (Objects.equals(sensorASTA, "Atuador A Avançado") && Objects.equals(sensorBSTA, "Atuador B Avançado") && Objects.equals(sensorCSTA, "Atuador C Avançado")) {
            // Condições para ciclo único
            if (recC_STA1) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1 = false;
                recB_STA1 = true;
            }
            // Condições para dois ciclos
            if (recC_STA1_2v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_2v = false;
                recB_STA1_2v = true;
            }
            // Condições para três ciclos
            if (recC_STA1_3v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_3v = false;
                recB_STA1_3v = true;
            }
            // Condições para quatro ciclos
            if (recC_STA1_4v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_4v = false;
                recB_STA1_4v = true;
            }
            // Condições para cinco ciclos
            if (recC_STA1_5v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_5v = false;
                recB_STA1_5v = true;
            }
            // Condições para seis ciclos
            if (recC_STA1_6v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_6v = false;
                recB_STA1_6v = true;
            }
            // Condições para sete ciclos
            if (recC_STA1_7v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_7v = false;
                recB_STA1_7v = true;
            }
            // Condições para oito ciclos
            if (recC_STA1_8v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_8v = false;
                recB_STA1_8v = true;
            }
            // Condições para nove ciclos
            if (recC_STA1_9v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_9v = false;
                recB_STA1_9v = true;
            }
            // Condições para dez ciclos
            if (recC_STA1_10v) {
                publishCmenos();
                aguard_concSTA.setText(R.string.recuandoC);
                gifC.setImageResource(R.drawable.gif_recuando_c);
                recC_STA1_10v = false;
                recB_STA1_10v = true;
            }
        }
    }

    private void startBackgroundLoop() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    // Coloque o código do loop aqui, e use handler.post() para qualquer manipulação da UI
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // Código a ser executado na thread principal (UI)
                            loop();
                        }
                    });

                    try {
                        // Aguarda 1 segundo antes de executar novamente
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Para o loop quando a atividade for destruída
        isRunning = false;
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
    // Funções para ativar modo tela cheia ao iniciar o aplicativo
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    public void showToast(String message) {
        ViewGroup view = findViewById(R.id.container_toast);
        View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

        TextView txtMessage = v.findViewById(R.id.txt_toast);
        txtMessage.setText(message);

        Toast toast = new Toast(this);
        toast.setView(v);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    private void connectMQTT() {
        if (mqtt.isConnected()) {
            showToast("Broker já conectado!");
            statusConexaoSTA.setText(R.string.conectado);
            btnConectarSTA.setVisibility(View.INVISIBLE);
            return;
        }
        Log.w(TAG, "Conectando ao broker MQTT...");
        statusConexaoSTA.setText(R.string.conectando);

        // Recupere o valor da string (USERNAME e PASSWORD) do Intent
        final String MQTT_USERNAME = getIntent().getStringExtra("MQTTUSUARIOTA");
        final String MQTT_PASSWORD = getIntent().getStringExtra("MQTTSENHATA");

        //Set option
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(MQTT_USERNAME);
        options.setPassword(MQTT_PASSWORD.toCharArray());
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        try {
            IMqttToken token = mqtt.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Connect success!");
                    statusConexaoSTA.setText(R.string.conectado);
                    //Subscribe
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error..." + exception.getMessage());
                    String tsx = "Falha na conexão... " + exception.getMessage();
                    statusConexaoSTA.setText(tsx);
                    btnConectarSTA.setVisibility(View.VISIBLE);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            String tsx = "Connect MqttException: " + e.getMessage();
            statusConexaoSTA.setText(tsx);
            btnConectarSTA.setVisibility(View.VISIBLE);
        }
    }

    private void disconnectMQTT() {
        Log.d(TAG, "Disconnecting MQTT server...");
        try {
            IMqttToken token = mqtt.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Disconnect success...");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Disconnect failed...");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "Error..." + e.getMessage());
        }
    }

    private void subscribe(@NonNull String topic) {
        //Connect
        if (!mqtt.isConnected()) {
            //showToast("Please connect before retry again");
            return;
        }

        try {
            //Set
            IMqttToken token = mqtt.subscribe(topic, 0);
            //Check result
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Subscribed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribed");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribe failed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribe error!");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            //showToast(e.getMessage());
        }
    }

    public void IniciaSTAUmaVez() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1 = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTADuasVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_2v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTATresVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_3v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTAQuatroVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_4v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTACincoVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_5v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTASeisVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_6v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTASeteVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_7v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTAOitoVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_8v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTANoveVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_9v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSTADezVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIATA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciadaSTA = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_concSTA = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciadaSTA.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);
        gifC = findViewById(R.id.iv_gifC);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciadaSTA.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+C+C-B-A-")) { // Sequência 1
            avcA_STA1_10v = true;
            startBackgroundLoop();
        }
    }

    public void publishAmais() {
        String topic = "/comando/valvA";
        String payload = "1"; // Avança o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmenos() {
        String topic = "/comando/valvA";
        String payload = "0"; // Recua o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmais() {
        String topic = "/comando/valvB";
        String payload = "1"; // Avança o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmenos() {
        String topic = "/comando/valvB";
        String payload = "0"; // Recua o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmais() {
        String topic = "/comando/valvC";
        String payload = "1"; // Avança o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmenos() {
        String topic = "/comando/valvC";
        String payload = "0"; // Recua o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}