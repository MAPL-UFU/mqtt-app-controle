package com.somsakelect.android.mqttcontrolapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.somsakelect.android.mqtt.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;

import android.os.Handler;
import android.os.Looper;

import pl.droidsonroids.gif.GifDrawable;

public class StartDoisAtuad extends AppCompatActivity {

    private Handler handler;
    private boolean isRunning = true;
    private boolean voltarInicio = false;
    private boolean avcA_seq1 = false, recA_seq1 = false, avcB_seq1 = false, recB_seq1 = false; // Sequência 1: A+ B+ A- B-
    private boolean avcA_seq2 = false, recA_seq2 = false, avcB_seq2 = false, recB_seq2 = false; // Sequência 2: A+ B+ B- A-
    private boolean avcA_seq3 = false, recA_seq3 = false, avcB_seq3 = false, recB_seq3 = false; // Sequência 3: A+ A- B+ B-
    private boolean avcA_seq1_2v = false, recA_seq1_2v = false, avcB_seq1_2v = false, recB_seq1_2v = false;
    private boolean avcA_seq2_2v = false, recA_seq2_2v = false, avcB_seq2_2v = false, recB_seq2_2v = false;
    private boolean avcA_seq3_2v = false, recA_seq3_2v = false, avcB_seq3_2v = false, recB_seq3_2v = false;
    private boolean avcA_seq1_3v = false, recA_seq1_3v = false, avcB_seq1_3v = false, recB_seq1_3v = false;
    private boolean avcA_seq2_3v = false, recA_seq2_3v = false, avcB_seq2_3v = false, recB_seq2_3v = false;
    private boolean avcA_seq3_3v = false, recA_seq3_3v = false, avcB_seq3_3v = false, recB_seq3_3v = false;
    private boolean avcA_seq1_4v = false, recA_seq1_4v = false, avcB_seq1_4v = false, recB_seq1_4v = false;
    private boolean avcA_seq2_4v = false, recA_seq2_4v = false, avcB_seq2_4v = false, recB_seq2_4v = false;
    private boolean avcA_seq3_4v = false, recA_seq3_4v = false, avcB_seq3_4v = false, recB_seq3_4v = false;
    private boolean avcA_seq1_5v = false, recA_seq1_5v = false, avcB_seq1_5v = false, recB_seq1_5v = false;
    private boolean avcA_seq2_5v = false, recA_seq2_5v = false, avcB_seq2_5v = false, recB_seq2_5v = false;
    private boolean avcA_seq3_5v = false, recA_seq3_5v = false, avcB_seq3_5v = false, recB_seq3_5v = false;
    private boolean avcA_seq1_6v = false, recA_seq1_6v = false, avcB_seq1_6v = false, recB_seq1_6v = false;
    private boolean avcA_seq2_6v = false, recA_seq2_6v = false, avcB_seq2_6v = false, recB_seq2_6v = false;
    private boolean avcA_seq3_6v = false, recA_seq3_6v = false, avcB_seq3_6v = false, recB_seq3_6v = false;
    private boolean avcA_seq1_7v = false, recA_seq1_7v = false, avcB_seq1_7v = false, recB_seq1_7v = false;
    private boolean avcA_seq2_7v = false, recA_seq2_7v = false, avcB_seq2_7v = false, recB_seq2_7v = false;
    private boolean avcA_seq3_7v = false, recA_seq3_7v = false, avcB_seq3_7v = false, recB_seq3_7v = false;
    private boolean avcA_seq1_8v = false, recA_seq1_8v = false, avcB_seq1_8v = false, recB_seq1_8v = false;
    private boolean avcA_seq2_8v = false, recA_seq2_8v = false, avcB_seq2_8v = false, recB_seq2_8v = false;
    private boolean avcA_seq3_8v = false, recA_seq3_8v = false, avcB_seq3_8v = false, recB_seq3_8v = false;
    private boolean avcA_seq1_9v = false, recA_seq1_9v = false, avcB_seq1_9v = false, recB_seq1_9v = false;
    private boolean avcA_seq2_9v = false, recA_seq2_9v = false, avcB_seq2_9v = false, recB_seq2_9v = false;
    private boolean avcA_seq3_9v = false, recA_seq3_9v = false, avcB_seq3_9v = false, recB_seq3_9v = false;
    private boolean avcA_seq1_10v = false, recA_seq1_10v = false, avcB_seq1_10v = false, recB_seq1_10v = false;
    private boolean avcA_seq2_10v = false, recA_seq2_10v = false, avcB_seq2_10v = false, recB_seq2_10v = false;
    private boolean avcA_seq3_10v = false, recA_seq3_10v = false, avcB_seq3_10v = false, recB_seq3_10v = false;

    private MqttAndroidClient mqtt;

    private TextView statusConexaoSDA, seq_iniciada, aguard_conc;
    private ImageView gifA, gifB;
    private EditText numCiclos;
    private String sensorA, sensorB;
    private LinearLayout btnConectarSDA;
    private static final String TAG = "StartDoisAtuad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_start_dois_atuad);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        handler = new Handler(Looper.getMainLooper());

        handler.post(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        });

        // Recupere o valor da string (HOST) do Intent
        final String MQTT_HOST = getIntent().getStringExtra("MQTTBROKER");
        final int MQTT_PORT = 1883;
        final String MQTT_URL = "tcp://" + MQTT_HOST + ":" + MQTT_PORT;
        final String MQTT_ID = getIntent().getStringExtra("MQTTID");

        statusConexaoSDA = findViewById(R.id.tv_statusConexaoSDA);
        numCiclos = findViewById(R.id.numCiclos_e);
        btnConectarSDA = (LinearLayout) findViewById(R.id.ll_btnConectarSDA);
        btnConectarSDA.setVisibility(View.INVISIBLE);

        //MQTT
        mqtt = new MqttAndroidClient(this, MQTT_URL, MQTT_ID);
        mqtt.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.w(TAG, "Reconexão MQTT..." + reconnect);
                statusConexaoSDA.setText(reconnect ? "Reconectando..." : "Conectado!");
                if (mqtt.isConnected()) {
                    String tsx = "CONECTADO!";
                    statusConexaoSDA.setText(tsx);
                    btnConectarSDA.setVisibility(View.INVISIBLE);
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                if (cause != null) {
                    Log.e(TAG, "Conexão MQTT perdida..." + cause.getMessage());
                    String st = "Conexão perdida! " + cause.getMessage();
                    statusConexaoSDA.setText(st);
                    btnConectarSDA.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                if (topic.equals("/estado/atuadorA")) {
                    //String sensorA;
                    sensorA = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorA", sensorA);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorB")) {
                    //String sensorB;
                    sensorB = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorB", sensorB);
                    Log.w(TAG, log);
                    //Debug
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.w(TAG, "Publish success...");
                //showToast("Publish success!");
            }
        });

        //Botão Conectar
        findViewById(R.id.conBrokerStartDoisAtuad_btn).setOnClickListener(v -> connectMQTT());

        //Botão Voltar
        findViewById(R.id.voltarStartDoisAtuad_btn).setOnClickListener(v -> {
            // Crie um Intent para iniciar MainActivity
            Intent mqtt_setup = new Intent(StartDoisAtuad.this, MainActivity.class);
            disconnectMQTT();
            // Inicie a MainActivity com o Intent
            startActivity(mqtt_setup);
        });

        //Botão Start
        findViewById(R.id.iniciaStartDoisAtuad_btn).setOnClickListener(v -> {
            try {
                int nciclos = 0;
                nciclos = Integer.parseInt(numCiclos.getText().toString());

                if (nciclos > 10 || nciclos < 1) {
                    numCiclos.setError("Apenas números de 1 a 10.");
                    numCiclos.requestFocus();
                } else {
                    if (nciclos == 1) {
                        IniciaSeqUmaVez();
                    }
                    if (nciclos == 2) {
                        IniciaSeqDuasVezes();
                    }
                    if (nciclos == 3) {
                        IniciaSeqTresVezes();
                    }
                    if (nciclos == 4) {
                        IniciaSeqQuatroVezes();
                    }
                    if (nciclos == 5) {
                        IniciaSeqCincoVezes();
                    }
                    if (nciclos == 6) {
                        IniciaSeqSeisVezes();
                    }
                    if (nciclos == 7) {
                        IniciaSeqSeteVezes();
                    }
                    if (nciclos == 8) {
                        IniciaSeqOitoVezes();
                    }
                    if (nciclos == 9) {
                        IniciaSeqNoveVezes();
                    }
                    if (nciclos == 10) {
                        IniciaSeqDezVezes();
                    }
                }

            } catch (Exception e) {
                numCiclos.setError("Digite um número!");
                numCiclos.requestFocus();
            }
        });

        //Try connect
        connectMQTT();
    }

    public void loop() {
        // Atuadores A e B estão recuados
        if (Objects.equals(sensorA, "Atuador A Recuado") && Objects.equals(sensorB, "Atuador B Recuado")) {
            // Condições para ciclo único
            if (avcA_seq1) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1 = false;
                avcB_seq1 = true;
            }
            if (avcA_seq2) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2 = false;
                avcB_seq2 = true;
            }
            if (avcA_seq3) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3 = false;
                recA_seq3 = true;
            }
            if (avcB_seq3) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3 = false;
                recB_seq3 = true;
            }
            // Condições para dois ciclos
            if (avcA_seq1_2v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_2v = false;
                avcB_seq1_2v = true;
            }
            if (avcA_seq2_2v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_2v = false;
                avcB_seq2_2v = true;
            }
            if (avcA_seq3_2v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_2v = false;
                recA_seq3_2v = true;
            }
            if (avcB_seq3_2v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_2v = false;
                recB_seq3_2v = true;
            }
            // Condições para três ciclos
            if (avcA_seq1_3v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_3v = false;
                avcB_seq1_3v = true;
            }
            if (avcA_seq2_3v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_3v = false;
                avcB_seq2_3v = true;
            }
            if (avcA_seq3_3v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_3v = false;
                recA_seq3_3v = true;
            }
            if (avcB_seq3_3v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_3v = false;
                recB_seq3_3v = true;
            }
            // Condições para quatro ciclos
            if (avcA_seq1_4v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_4v = false;
                avcB_seq1_4v = true;
            }
            if (avcA_seq2_4v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_4v = false;
                avcB_seq2_4v = true;
            }
            if (avcA_seq3_4v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_4v = false;
                recA_seq3_4v = true;
            }
            if (avcB_seq3_4v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_4v = false;
                recB_seq3_4v = true;
            }
            // Condições para cinco ciclos
            if (avcA_seq1_5v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_5v = false;
                avcB_seq1_5v = true;
            }
            if (avcA_seq2_5v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_5v = false;
                avcB_seq2_5v = true;
            }
            if (avcA_seq3_5v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_5v = false;
                recA_seq3_5v = true;
            }
            if (avcB_seq3_5v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_5v = false;
                recB_seq3_5v = true;
            }
            // Condições para seis ciclos
            if (avcA_seq1_6v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_6v = false;
                avcB_seq1_6v = true;
            }
            if (avcA_seq2_6v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_6v = false;
                avcB_seq2_6v = true;
            }
            if (avcA_seq3_6v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_6v = false;
                recA_seq3_6v = true;
            }
            if (avcB_seq3_6v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_6v = false;
                recB_seq3_6v = true;
            }
            // Condições para sete ciclos
            if (avcA_seq1_7v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_7v = false;
                avcB_seq1_7v = true;
            }
            if (avcA_seq2_7v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_7v = false;
                avcB_seq2_7v = true;
            }
            if (avcA_seq3_7v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_7v = false;
                recA_seq3_7v = true;
            }
            if (avcB_seq3_7v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_7v = false;
                recB_seq3_7v = true;
            }
            // Condições para oito ciclos
            if (avcA_seq1_8v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_8v = false;
                avcB_seq1_8v = true;
            }
            if (avcA_seq2_8v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_8v = false;
                avcB_seq2_8v = true;
            }
            if (avcA_seq3_8v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_8v = false;
                recA_seq3_8v = true;
            }
            if (avcB_seq3_8v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_8v = false;
                recB_seq3_8v = true;
            }
            // Condições para nove ciclos
            if (avcA_seq1_9v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_9v = false;
                avcB_seq1_9v = true;
            }
            if (avcA_seq2_9v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_9v = false;
                avcB_seq2_9v = true;
            }
            if (avcA_seq3_9v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_9v = false;
                recA_seq3_9v = true;
            }
            if (avcB_seq3_9v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_9v = false;
                recB_seq3_9v = true;
            }
            // Condições para dez ciclos
            if (avcA_seq1_10v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq1_10v = false;
                avcB_seq1_10v = true;
            }
            if (avcA_seq2_10v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq2_10v = false;
                avcB_seq2_10v = true;
            }
            if (avcA_seq3_10v) {
                publishAmais();
                aguard_conc.setText(R.string.avancandoA);
                gifA.setImageResource(R.drawable.gif_avancando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                avcA_seq3_10v = false;
                recA_seq3_10v = true;
            }
            if (avcB_seq3_10v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq3_10v = false;
                recB_seq3_10v = true;
            }
            // Finalizando sequência e voltando para tela inicial
            if (voltarInicio) {
                voltarInicio = false;
                // Crie um Intent para iniciar MainActivity
                Intent mqtt_setup = new Intent(StartDoisAtuad.this, MainActivity.class);
                disconnectMQTT();
                // Inicie a MainActivity com o Intent
                startActivity(mqtt_setup);
            }
        }
        // Atuador A está avançado e atuador B está recuado
        if (Objects.equals(sensorA, "Atuador A Avançado") && Objects.equals(sensorB, "Atuador B Recuado")) {
            // Condições para ciclo único
            if (avcB_seq1) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1 = false;
                recA_seq1 = true;
            }
            if (avcB_seq2) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2 = false;
                recB_seq2 = true;
            }
            if (recA_seq2) {
                publishAmenos();
                seq_iniciada.setText(R.string.seqFinalizando);
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2 = false;
                // Fim da sequência onDestroy();
                voltarInicio = true;
            }
            if (recA_seq3) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3 = false;
                avcB_seq3 = true;
            }
            // Condições para dois ciclos
            if (avcB_seq1_2v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_2v = false;
                recA_seq1_2v = true;
            }
            if (avcB_seq2_2v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_2v = false;
                recB_seq2_2v = true;
            }
            if (recA_seq2_2v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_2v = false;
                // Inicia ciclo único da sequência 2
                avcA_seq2 = true;
            }
            if (recA_seq3_2v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_2v = false;
                avcB_seq3_2v = true;
            }
            // Condições para três ciclos
            if (avcB_seq1_3v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_3v = false;
                recA_seq1_3v = true;
            }
            if (avcB_seq2_3v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_3v = false;
                recB_seq2_3v = true;
            }
            if (recA_seq2_3v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_3v = false;
                // Inicia dois ciclos da sequência 2
                avcA_seq2_2v = true;
            }
            if (recA_seq3_3v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_3v = false;
                avcB_seq3_3v = true;
            }
            // Condições para quatro ciclos
            if (avcB_seq1_4v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_4v = false;
                recA_seq1_4v = true;
            }
            if (avcB_seq2_4v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_4v = false;
                recB_seq2_4v = true;
            }
            if (recA_seq2_4v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_4v = false;
                // Inicia três ciclos da sequência 2
                avcA_seq2_3v = true;
            }
            if (recA_seq3_4v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_4v = false;
                avcB_seq3_4v = true;
            }
            // Condições para cinco ciclos
            if (avcB_seq1_5v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_5v = false;
                recA_seq1_5v = true;
            }
            if (avcB_seq2_5v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_5v = false;
                recB_seq2_5v = true;
            }
            if (recA_seq2_5v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_5v = false;
                // Inicia quatro ciclos da sequência 2
                avcA_seq2_4v = true;
            }
            if (recA_seq3_5v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_5v = false;
                avcB_seq3_5v = true;
            }
            // Condições para seis ciclos
            if (avcB_seq1_6v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_6v = false;
                recA_seq1_6v = true;
            }
            if (avcB_seq2_6v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_6v = false;
                recB_seq2_6v = true;
            }
            if (recA_seq2_6v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_6v = false;
                // Inicia cinco ciclos da sequência 2
                avcA_seq2_5v = true;
            }
            if (recA_seq3_6v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_6v = false;
                avcB_seq3_6v = true;
            }
            // Condições para sete ciclos
            if (avcB_seq1_7v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_7v = false;
                recA_seq1_7v = true;
            }
            if (avcB_seq2_7v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_7v = false;
                recB_seq2_7v = true;
            }
            if (recA_seq2_7v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_7v = false;
                // Inicia seis ciclos da sequência 2
                avcA_seq2_6v = true;
            }
            if (recA_seq3_7v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_7v = false;
                avcB_seq3_7v = true;
            }
            // Condições para oito ciclos
            if (avcB_seq1_8v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_8v = false;
                recA_seq1_8v = true;
            }
            if (avcB_seq2_8v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_8v = false;
                recB_seq2_8v = true;
            }
            if (recA_seq2_8v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_8v = false;
                // Inicia sete ciclos da sequência 2
                avcA_seq2_7v = true;
            }
            if (recA_seq3_8v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_8v = false;
                avcB_seq3_8v = true;
            }
            // Condições para nove ciclos
            if (avcB_seq1_9v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_9v = false;
                recA_seq1_9v = true;
            }
            if (avcB_seq2_9v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_9v = false;
                recB_seq2_9v = true;
            }
            if (recA_seq2_9v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_9v = false;
                // Inicia oito ciclos da sequência 2
                avcA_seq2_8v = true;
            }
            if (recA_seq3_9v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_9v = false;
                avcB_seq3_9v = true;
            }
            // Condições para dez ciclos
            if (avcB_seq1_10v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq1_10v = false;
                recA_seq1_10v = true;
            }
            if (avcB_seq2_10v) {
                publishBmais();
                aguard_conc.setText(R.string.avancandoB);
                gifA.setImageResource(R.drawable.atuador_a_avancado);
                gifB.setImageResource(R.drawable.gif_avancando_b);
                avcB_seq2_10v = false;
                recB_seq2_10v = true;
            }
            if (recA_seq2_10v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_recuado);
                recA_seq2_10v = false;
                // Inicia nove ciclos da sequência 2
                avcA_seq2_9v = true;
            }
            if (recA_seq3_10v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                recA_seq3_10v = false;
                avcB_seq3_10v = true;
            }
        }
        // Atuadores A e B estão avançados
        if (Objects.equals(sensorA, "Atuador A Avançado") && Objects.equals(sensorB, "Atuador B Avançado")) {
            // Condições para ciclo único
            if (recA_seq1) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1 = false;
                recB_seq1 = true;
            }
            if (recB_seq2) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2 = false;
                recA_seq2 = true;
            }
            // Condições para dois ciclos
            if (recA_seq1_2v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_2v = false;
                recB_seq1_2v = true;
            }
            if (recB_seq2_2v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_2v = false;
                recA_seq2_2v = true;
            }
            // Condições para três ciclos
            if (recA_seq1_3v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_3v = false;
                recB_seq1_3v = true;
            }
            if (recB_seq2_3v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_3v = false;
                recA_seq2_3v = true;
            }
            // Condições para quatro ciclos
            if (recA_seq1_4v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_4v = false;
                recB_seq1_4v = true;
            }
            if (recB_seq2_4v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_4v = false;
                recA_seq2_4v = true;
            }
            // Condições para cinco ciclos
            if (recA_seq1_5v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_5v = false;
                recB_seq1_5v = true;
            }
            if (recB_seq2_5v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_5v = false;
                recA_seq2_5v = true;
            }
            // Condições para seis ciclos
            if (recA_seq1_6v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_6v = false;
                recB_seq1_6v = true;
            }
            if (recB_seq2_6v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_6v = false;
                recA_seq2_6v = true;
            }
            // Condições para sete ciclos
            if (recA_seq1_7v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_7v = false;
                recB_seq1_7v = true;
            }
            if (recB_seq2_7v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_7v = false;
                recA_seq2_7v = true;
            }
            // Condições para oito ciclos
            if (recA_seq1_8v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_8v = false;
                recB_seq1_8v = true;
            }
            if (recB_seq2_8v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_8v = false;
                recA_seq2_8v = true;
            }
            // Condições para nove ciclos
            if (recA_seq1_9v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_9v = false;
                recB_seq1_9v = true;
            }
            if (recB_seq2_9v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_9v = false;
                recA_seq2_9v = true;
            }
            // Condições para dez ciclos
            if (recA_seq1_10v) {
                publishAmenos();
                aguard_conc.setText(R.string.recuandoA);
                gifA.setImageResource(R.drawable.gif_recuando_a);
                gifB.setImageResource(R.drawable.atuador_b_avancado);
                recA_seq1_10v = false;
                recB_seq1_10v = true;
            }
            if (recB_seq2_10v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq2_10v = false;
                recA_seq2_10v = true;
            }
        }
        // Atuador A está recuado e atuador B está avançado
        if (Objects.equals(sensorA, "Atuador A Recuado") && Objects.equals(sensorB, "Atuador B Avançado")) {
            // Condições para ciclo único
            if (recB_seq1) {
                publishBmenos();
                seq_iniciada.setText(R.string.seqFinalizando);
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1 = false;
                // Fim da sequência onDestroy();
                voltarInicio = true;
            }
            if (recB_seq3) {
                publishBmenos();
                seq_iniciada.setText(R.string.seqFinalizando);
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3 = false;
                // Fim da sequência onDestroy();
                voltarInicio = true;
            }
            // Condições para dois ciclos
            if (recB_seq1_2v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_2v = false;
                // Inicia ciclo único da sequência 1
                avcA_seq1 = true;
            }
            if (recB_seq3_2v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_2v = false;
                // Inicia ciclo único da sequência 3
                avcA_seq3 = true;
            }
            // Condições para três ciclos
            if (recB_seq1_3v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_3v = false;
                // Inicia dois ciclos da sequência 1
                avcA_seq1_2v = true;
            }
            if (recB_seq3_3v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_3v = false;
                // Inicia dois ciclos da sequência 3
                avcA_seq3_2v = true;
            }
            // Condições para quatro ciclos
            if (recB_seq1_4v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_4v = false;
                // Inicia três ciclos da sequência 1
                avcA_seq1_3v = true;
            }
            if (recB_seq3_4v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_4v = false;
                // Inicia três ciclos da sequência 3
                avcA_seq3_3v = true;
            }
            // Condições para cinco ciclos
            if (recB_seq1_5v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_5v = false;
                // Inicia quatro ciclos da sequência 1
                avcA_seq1_4v = true;
            }
            if (recB_seq3_5v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_5v = false;
                // Inicia quatro ciclos da sequência 3
                avcA_seq3_4v = true;
            }
            // Condições para seis ciclos
            if (recB_seq1_6v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_6v = false;
                // Inicia cinco ciclos da sequência 1
                avcA_seq1_5v = true;
            }
            if (recB_seq3_6v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_6v = false;
                // Inicia cinco ciclos da sequência 3
                avcA_seq3_5v = true;
            }
            // Condições para sete ciclos
            if (recB_seq1_7v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_7v = false;
                // Inicia seis ciclos da sequência 1
                avcA_seq1_6v = true;
            }
            if (recB_seq3_7v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_7v = false;
                // Inicia seis ciclos da sequência 3
                avcA_seq3_6v = true;
            }
            // Condições para oito ciclos
            if (recB_seq1_8v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_8v = false;
                // Inicia sete ciclos da sequência 1
                avcA_seq1_7v = true;
            }
            if (recB_seq3_8v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_8v = false;
                // Inicia sete ciclos da sequência 3
                avcA_seq3_7v = true;
            }
            // Condições para nove ciclos
            if (recB_seq1_9v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_9v = false;
                // Inicia oito ciclos da sequência 1
                avcA_seq1_8v = true;
            }
            if (recB_seq3_9v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_9v = false;
                // Inicia oito ciclos da sequência 3
                avcA_seq3_8v = true;
            }
            // Condições para dez ciclos
            if (recB_seq1_10v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifA.setImageResource(R.drawable.atuador_a_recuado);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq1_10v = false;
                // Inicia nove ciclos da sequência 1
                avcA_seq1_9v = true;
            }
            if (recB_seq3_10v) {
                publishBmenos();
                aguard_conc.setText(R.string.recuandoB);
                gifB.setImageResource(R.drawable.gif_recuando_b);
                recB_seq3_10v = false;
                // Inicia nove ciclos da sequência 3
                avcA_seq3_9v = true;
            }
        }
    }

    private void startBackgroundLoop() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    // Coloque o código do loop aqui, e use handler.post() para qualquer manipulação da UI
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // Código a ser executado na thread principal (UI)
                            loop();
                        }
                    });

                    try {
                        // Aguarda 1 segundo antes de executar novamente
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Para o loop quando a atividade for destruída
        isRunning = false;
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
    // Funções para ativar modo tela cheia ao iniciar o aplicativo
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    public void showToast(String message) {
        ViewGroup view = findViewById(R.id.container_toast);
        View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

        TextView txtMessage = v.findViewById(R.id.txt_toast);
        txtMessage.setText(message);

        Toast toast = new Toast(this);
        toast.setView(v);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    private void connectMQTT() {
        if (mqtt.isConnected()) {
            showToast("Broker já conectado!");
            statusConexaoSDA.setText(R.string.conectado);
            btnConectarSDA.setVisibility(View.INVISIBLE);
            return;
        }
        Log.w(TAG, "Conectando ao broker MQTT...");
        statusConexaoSDA.setText(R.string.conectando);

        // Recupere o valor da string (USERNAME e PASSWORD) do Intent
        final String MQTT_USERNAME = getIntent().getStringExtra("MQTTUSUARIO");
        final String MQTT_PASSWORD = getIntent().getStringExtra("MQTTSENHA");

        //Set option
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(MQTT_USERNAME);
        options.setPassword(MQTT_PASSWORD.toCharArray());
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        try {
            IMqttToken token = mqtt.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Connect success!");
                    statusConexaoSDA.setText(R.string.conectado);
                    //Subscribe
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error..." + exception.getMessage());
                    String tsx = "Falha na conexão... " + exception.getMessage();
                    statusConexaoSDA.setText(tsx);
                    btnConectarSDA.setVisibility(View.VISIBLE);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            String tsx = "Connect MqttException: " + e.getMessage();
            statusConexaoSDA.setText(tsx);
            btnConectarSDA.setVisibility(View.VISIBLE);
        }
    }

    private void disconnectMQTT() {
        Log.d(TAG, "Disconnecting MQTT server...");
        try {
            IMqttToken token = mqtt.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Disconnect success...");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Disconnect failed...");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "Error..." + e.getMessage());
        }
    }

    private void subscribe(@NonNull String topic) {
        //Connect
        if (!mqtt.isConnected()) {
            //showToast("Please connect before retry again");
            return;
        }

        try {
            //Set
            IMqttToken token = mqtt.subscribe(topic, 0);
            //Check result
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Subscribed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribed");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribe failed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribe error!");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            //showToast(e.getMessage());
        }
    }

    public void IniciaSeqUmaVez() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        //Connect
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1 = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2 = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3 = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqDuasVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_2v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_2v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_2v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqTresVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_3v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_3v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_3v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqQuatroVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_4v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_4v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_4v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqCincoVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_5v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_5v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_5v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqSeisVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_6v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_6v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_6v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqSeteVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_7v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_7v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_7v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqOitoVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_8v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_8v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_8v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqNoveVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_9v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_9v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_9v = true;
            startBackgroundLoop();
        }
    }

    public void IniciaSeqDezVezes() {

        final String SEQUENCIA = getIntent().getStringExtra("MQTTSEQUENCIA");

        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }

        setContentView(R.layout.tela_de_espera); // Inicia outro layout
        seq_iniciada = findViewById(R.id.tv_sequenciaIniciadaSDA); // Passa ID para a variável TextView
        aguard_conc = findViewById(R.id.tv_aguardandoConclusaoSDA); // Passa ID para a variável TextView
        seq_iniciada.setText(R.string.seqAndamento); // Altera o texto do TextView

        gifA = findViewById(R.id.iv_gifA);
        gifB = findViewById(R.id.iv_gifB);

        Animation animation = new AlphaAnimation(1.0f, 0.0f); // Comando para piscar o TextView
        animation.setDuration(1000); // Definição do tempo de duração da animação
        animation.setRepeatMode(Animation.REVERSE);
        animation.setRepeatCount(Animation.INFINITE);
        seq_iniciada.startAnimation(animation); // Definindo o TextView

        if (Objects.equals(SEQUENCIA, "A+B+A-B-")) { // Sequência 1
            avcA_seq1_10v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+B+B-A-")) { // Sequência 2
            avcA_seq2_10v = true;
            startBackgroundLoop();
        }
        if (Objects.equals(SEQUENCIA, "A+A-B+B-")) { // Sequência 3
            avcA_seq3_10v = true;
            startBackgroundLoop();
        }
    }

    public void publishAmais() {
        String topic = "/comando/valvA";
        String payload = "1"; // Avança o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmenos() {
        String topic = "/comando/valvA";
        String payload = "0"; // Recua o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmais() {
        String topic = "/comando/valvB";
        String payload = "1"; // Avança o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmenos() {
        String topic = "/comando/valvB";
        String payload = "0"; // Recua o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}