package com.somsakelect.android.mqttcontrolapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.somsakelect.android.mqtt.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class ComandoTresAtuad extends AppCompatActivity {
    private static final int ATENCAO = 1;
    private static final int SUCESSO = 2;
    private static final int ERRO = 3;
    private MqttAndroidClient mqtt;

    private TextView estadoA, estadoB, estadoC, statusConexao;
    private String sensorA, sensorB, sensorC;
    private LinearLayout btnConectar;
    private static final String TAG = "ComandoTresAtuad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_com_tres_atuad);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Recupere o valor da string (HOST) do Intent
        final String MQTT_HOST = getIntent().getStringExtra("MQTT_BROKER");
        final int MQTT_PORT = 1883;
        final String MQTT_URL = "tcp://" + MQTT_HOST + ":" + MQTT_PORT;
        final String MQTT_ID = MqttClient.generateClientId();

        estadoA = findViewById(R.id.tv_estadoAtuadorA);
        estadoB = findViewById(R.id.tv_estadoAtuadorB);
        estadoC = findViewById(R.id.tv_estadoAtuadorC);
        statusConexao = findViewById(R.id.tv_statusConexao);
        btnConectar = findViewById(R.id.ll_btnConectarCTA);

        //MQTT
        mqtt = new MqttAndroidClient(this, MQTT_URL, MQTT_ID);
        mqtt.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.w(TAG, "Reconexão MQTT..." + reconnect);
                statusConexao.setText(reconnect ? "Reconectando..." : "Conectado!");
                if (mqtt.isConnected()) {
                    String tsx = "CONECTADO!";
                    statusConexao.setText(tsx);
                    btnConectar.setVisibility(View.INVISIBLE);
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                if (cause != null) {
                    Log.e(TAG, "Conexão MQTT perdida..." + cause.getMessage());
                    String st = "Conexão perdida! " + cause.getMessage();
                    statusConexao.setText(st);
                    btnConectar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                if (topic.equals("/estado/atuadorA")) {
                    //String sensorA;
                    sensorA = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorA", sensorA);
                    Log.w(TAG, log);
                    estadoA.setText(log);
                }
                if (topic.equals("/estado/atuadorB")) {
                    //String sensorB;
                    sensorB = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorB", sensorB);
                    Log.w(TAG, log);
                    estadoB.setText(log);
                }
                if (topic.equals("/estado/atuadorC")) {
                    //String sensorC;
                    sensorC = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorC", sensorC);
                    Log.w(TAG, log);
                    estadoC.setText(log);
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.w(TAG, "Publish success...");
            }
        });

        //Botão Avançar A
        findViewById(R.id.avancarA_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorA == null) {
                showToast(ATENCAO,"Subscrever estado do atuador A!");
                return;
            }
            if (sensorA.equals("Atuador A Avançado")) {
                showToast(ATENCAO,"Atuador A já está avançado!");
                return;
            }
            if (sensorA.equals("Atuador A Recuado")) {
                publishAmais();
                showToast(SUCESSO,"Avançando atuador A...");
            }
            if (sensorA.equals("Sensor(es) do Atuador A com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Recuar A
        findViewById(R.id.recuarA_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorA == null) {
                showToast(ATENCAO,"Subscrever estado do atuador A!");
                return;
            }
            if (sensorA.equals("Atuador A Recuado")) {
                showToast(ATENCAO,"Atuador A já está recuado!");
                return;
            }
            if (sensorA.equals("Atuador A Avançado")) {
                publishAmenos();
                showToast(SUCESSO,"Recuando atuador A...");
            }
            if (sensorA.equals("Sensor(es) do Atuador A com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Avançar B
        findViewById(R.id.avancarB_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorB == null) {
                showToast(ATENCAO,"Subscrever estado do atuador B!");
                return;
            }
            if (sensorB.equals("Atuador B Avançado")) {
                showToast(ATENCAO,"Atuador B já está avançado!");
                return;
            }
            if (sensorB.equals("Atuador B Recuado")) {
                publishBmais();
                showToast(SUCESSO,"Avançando atuador B...");
            }
            if (sensorB.equals("Sensor(es) do Atuador B com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Recuar B
        findViewById(R.id.recuarB_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorB == null) {
                showToast(ATENCAO,"Subscrever estado do atuador B!");
                return;
            }
            if (sensorB.equals("Atuador B Recuado")) {
                showToast(ATENCAO,"Atuador B já está recuado!");
                return;
            }
            if (sensorB.equals("Atuador B Avançado")) {
                publishBmenos();
                showToast(SUCESSO,"Recuando atuador B...");
            }
            if (sensorB.equals("Sensor(es) do Atuador B com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Avançar C
        findViewById(R.id.avancarC_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorC == null) {
                showToast(ATENCAO,"Subscrever estado do atuador C!");
                return;
            }
            if (sensorC.equals("Atuador C Avançado")) {
                showToast(ATENCAO,"Atuador C já está avançado!");
                return;
            }
            if (sensorC.equals("Atuador C Recuado")) {
                publishCmais();
                showToast(SUCESSO,"Avançando atuador C...");
            }
            if (sensorC.equals("Sensor(es) do Atuador C com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Recuar C
        findViewById(R.id.recuarC_btn).setOnClickListener(v -> {
            if (!mqtt.isConnected()) {
                showToast(ERRO,"Conecte-se ao broker e tente novamente!");
                return;
            }
            if (sensorC == null) {
                showToast(ATENCAO,"Subscrever estado do atuador C!");
                return;
            }
            if (sensorC.equals("Atuador C Recuado")) {
                showToast(ATENCAO,"Atuador C já está recuado!");
                return;
            }
            if (sensorC.equals("Atuador C Avançado")) {
                publishCmenos();
                showToast(SUCESSO,"Recuando atuador C...");
            }
            if (sensorC.equals("Sensor(es) do Atuador C com mau contato!")) {
                showToast(ERRO,"ERRO NO SENSOR!");
            }
        });

        //Botão Connect
        findViewById(R.id.con_btn).setOnClickListener(v -> connectMQTT());

        //Botão Voltar
        findViewById(R.id.voltar_btn).setOnClickListener(v -> {
            // Crie um Intent para iniciar MainActivity
            Intent mqtt_setup = new Intent(ComandoTresAtuad.this, MainActivity.class);
            disconnectMQTT();
            // Inicie a TresAtuad com o Intent
            startActivity(mqtt_setup);
        });

        //Try connect
        connectMQTT();
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
    // Funções para ativar modo tela cheia ao iniciar o aplicativo
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    public void showToast(int type, String message) {

        switch (type) {
            case ATENCAO:
                ViewGroup view = findViewById(R.id.container_toast);
                View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

                v.setBackground(ContextCompat.getDrawable(this, R.drawable.toast_atencao));

                TextView txtMessage = v.findViewById(R.id.txt_toast);
                txtMessage.setText(message);

                Toast toast = new Toast(this);
                toast.setView(v);
                toast.setDuration(Toast.LENGTH_SHORT);
                toast.show();
                break;
            case SUCESSO:
                ViewGroup view2 = findViewById(R.id.container_toast_sucesso);
                View v2 = getLayoutInflater().inflate(R.layout.success_toast, view2);

                v2.setBackground(ContextCompat.getDrawable(this, R.drawable.toast_sucesso));

                TextView txtMessage2 = v2.findViewById(R.id.txt_toast);
                txtMessage2.setText(message);

                Toast toast2 = new Toast(this);
                toast2.setView(v2);
                toast2.setDuration(Toast.LENGTH_SHORT);
                toast2.show();
                break;
            case ERRO:
                ViewGroup view3 = findViewById(R.id.container_toast_erro);
                View v3 = getLayoutInflater().inflate(R.layout.error_toast, view3);

                v3.setBackground(ContextCompat.getDrawable(this, R.drawable.toast_erro));

                TextView txtMessage3 = v3.findViewById(R.id.txt_toast);
                txtMessage3.setText(message);

                Toast toast3 = new Toast(this);
                toast3.setView(v3);
                toast3.setDuration(Toast.LENGTH_SHORT);
                toast3.show();
                break;

            default:
                throw new IllegalStateException("Erro de tipo " + message);
        }
    }

    private void connectMQTT() {
        if (mqtt.isConnected()) {
            showToast(ATENCAO,"Broker já conectado!");
            statusConexao.setText(R.string.conectado);
            btnConectar.setVisibility(View.INVISIBLE);
            return;
        }
        Log.w(TAG, "Conectando ao broker MQTT...");
        statusConexao.setText(R.string.conectando);

        // Recupere o valor da string (USERNAME e PASSWORD) do Intent
        final String MQTT_USERNAME = getIntent().getStringExtra("MQTT_USUARIO");
        final String MQTT_PASSWORD = getIntent().getStringExtra("MQTT_SENHA");

        //Set option
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(MQTT_USERNAME);
        options.setPassword(MQTT_PASSWORD.toCharArray());
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        try {
            IMqttToken token = mqtt.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Connect success!");
                    //Subscribe
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error..." + exception.getMessage());
                    String tsx = "Falha na conexão... " + exception.getMessage();
                    statusConexao.setText(tsx);
                    btnConectar.setVisibility(View.VISIBLE);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            String tsx = "Connect MqttException: " + e.getMessage();
            statusConexao.setText(tsx);
            btnConectar.setVisibility(View.VISIBLE);
        }
    }

    private void disconnectMQTT() {
        Log.d(TAG, "Disconnecting MQTT server...");
        try {
            IMqttToken token = mqtt.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Disconnect success...");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Disconnect failed...");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "Error..." + e.getMessage());
        }
    }

    private void subscribe(@NonNull String topic) {
        //Connect
        if (!mqtt.isConnected()) {
            return;
        }

        try {
            //Set
            IMqttToken token = mqtt.subscribe(topic, 0);
            //Check result
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Subscribed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribe failed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmais() {
        String topic = "/comando/valvA";
        String payload = "1"; // Avança o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmenos() {
        String topic = "/comando/valvA";
        String payload = "0"; // Recua o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmais() {
        String topic = "/comando/valvB";
        String payload = "1"; // Avança o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmenos() {
        String topic = "/comando/valvB";
        String payload = "0"; // Recua o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmais() {
        String topic = "/comando/valvC";
        String payload = "1"; // Avança o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmenos() {
        String topic = "/comando/valvC";
        String payload = "0"; // Recua o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}