package com.somsakelect.android.mqttcontrolapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.somsakelect.android.mqtt.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class DoisAtuad extends AppCompatActivity {
    private MqttAndroidClient mqtt;

    private TextView statusConexaoDoisAtuad;
    private EditText eAmaisDoisAtuad, eAmenosDoisAtuad, eBmaisDoisAtuad, eBmenosDoisAtuad, eKDoisAtuad;
    private String msgstatusSensDoisAtuad, msgstatusValvADoisAtuad, msgstatusValvBDoisAtuad, sensorADoisAtuad, sensorBDoisAtuad;
    private LinearLayout btnConectarDA;
    private static final String TAG = "DoisAtuad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_dois_atuad);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); // Manter a tela ligada para evitar desconexão com o broker

        // Recupere o valor da string (HOST) do Intent
        final String MQTT_HOST = getIntent().getStringExtra("MQTT_BROKER");
        final int MQTT_PORT = 1883;
        final String MQTT_URL = "tcp://" + MQTT_HOST + ":" + MQTT_PORT;
        final String MQTT_ID = MqttClient.generateClientId();

        statusConexaoDoisAtuad = findViewById(R.id.tv_statusConexaoDoisAtuad);
        eAmaisDoisAtuad = findViewById(R.id.AmaisDoisAtuad_e);
        eAmenosDoisAtuad = findViewById(R.id.AmenosDoisAtuad_e);
        eBmaisDoisAtuad = findViewById(R.id.BmaisDoisAtuad_e);
        eBmenosDoisAtuad = findViewById(R.id.BmenosDoisAtuad_e);
        eKDoisAtuad = findViewById(R.id.KDoisAtuad_e);
        btnConectarDA = findViewById(R.id.ll_btnConectarDA);

        //MQTT
        mqtt = new MqttAndroidClient(this, MQTT_URL, MQTT_ID);
        mqtt.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.w(TAG, "Reconexão MQTT..." + reconnect);
                statusConexaoDoisAtuad.setText(reconnect ? "Reconectando..." : "Conectado!");
                if (mqtt.isConnected()) {
                    String tsx = "CONECTADO!";
                    statusConexaoDoisAtuad.setText(tsx);
                    btnConectarDA.setVisibility(View.INVISIBLE);
                    subscribe("/status/espSensores"); // Recebe o status do ESP32 dos sensores de fim de curso
                    subscribe("/status/espValvA"); // Recebe o status do ESP32 da válvula A
                    subscribe("/status/espValvB"); // Recebe o status do ESP32 da válvula B
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                if (cause != null) {
                    Log.e(TAG, "Conexão MQTT perdida..." + cause.getMessage());
                    String st = "Conexão perdida! " + cause.getMessage();
                    statusConexaoDoisAtuad.setText(st);
                    btnConectarDA.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                if (topic.equals("/status/espSensores")) {
                    //String statusSensores;
                    msgstatusSensDoisAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espSensores", msgstatusSensDoisAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/status/espValvA")) {
                    //String statusValvA;
                    msgstatusValvADoisAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espValvA", msgstatusValvADoisAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/status/espValvB")) {
                    //String statusValvB;
                    msgstatusValvBDoisAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espValvB", msgstatusValvBDoisAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorA")) {
                    //String sensorA;
                    sensorADoisAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorA", sensorADoisAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorB")) {
                    //String sensorB;
                    sensorBDoisAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorB", sensorBDoisAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.w(TAG, "Publish success...");
                //showToast("Publish success!");
            }
        });

        //Botão Conectar
        findViewById(R.id.conBrokerDoisAtuad_btn).setOnClickListener(v -> connectMQTT());

        //Botão Voltar
        findViewById(R.id.voltarDoisAtuad_btn).setOnClickListener(v -> {
            // Crie um Intent para iniciar MainActivity
            Intent mqtt_setup = new Intent(DoisAtuad.this, MainActivity.class);
            disconnectMQTT();
            // Inicie a TresAtuad com o Intent
            startActivity(mqtt_setup);
        });

        //Botão Confirmar
        findViewById(R.id.confirmDoisAtuad_btn).setOnClickListener(v -> ConfereSeq(getEnter(eAmaisDoisAtuad), getEnter(eAmenosDoisAtuad), getEnter(eBmaisDoisAtuad), getEnter(eBmenosDoisAtuad), getEnter(eKDoisAtuad), sensorADoisAtuad, sensorBDoisAtuad));

        //Try connect
        connectMQTT();
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
    // Funções para ativar modo tela cheia ao iniciar o aplicativo
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    public void showToast(String message) {
        ViewGroup view = findViewById(R.id.container_toast);
        View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

        TextView txtMessage = v.findViewById(R.id.txt_toast);
        txtMessage.setText(message);

        Toast toast = new Toast(this);
        toast.setView(v);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    // Função para salvar os campos de input (EditText) como string
    private String getEnter(EditText e) {
        return e.getText().toString();
    }

    private void connectMQTT() {
        if (mqtt.isConnected()) {
            showToast("Broker já conectado!");
            statusConexaoDoisAtuad.setText(R.string.conectado);
            btnConectarDA.setVisibility(View.INVISIBLE);
            return;
        }
        Log.w(TAG, "Conectando ao broker MQTT...");
        statusConexaoDoisAtuad.setText(R.string.conectando);

        // Recupere o valor da string (USERNAME e PASSWORD) do Intent
        final String MQTT_USERNAME = getIntent().getStringExtra("MQTT_USUARIO");
        final String MQTT_PASSWORD = getIntent().getStringExtra("MQTT_SENHA");

        //Set option
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(MQTT_USERNAME);
        options.setPassword(MQTT_PASSWORD.toCharArray());
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        try {
            IMqttToken token = mqtt.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Connect success!");
                    //Subscribe
                    subscribe("/status/espSensores"); // Recebe o status do ESP32 dos sensores de fim de curso
                    subscribe("/status/espValvA"); // Recebe o status do ESP32 da válvula A
                    subscribe("/status/espValvB"); // Recebe o status do ESP32 da válvula B
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error..." + exception.getMessage());
                    String tsx = "Falha na conexão... " + exception.getMessage();
                    statusConexaoDoisAtuad.setText(tsx);
                    btnConectarDA.setVisibility(View.VISIBLE);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            String tsx = "Connect MqttException: " + e.getMessage();
            statusConexaoDoisAtuad.setText(tsx);
            btnConectarDA.setVisibility(View.VISIBLE);
        }
    }

    private void disconnectMQTT() {
        Log.d(TAG, "Disconnecting MQTT server...");
        try {
            IMqttToken token = mqtt.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Disconnect success...");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Disconnect failed...");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "Error..." + e.getMessage());
        }
    }

    private void subscribe(@NonNull String topic) {
        //Connect
        if (!mqtt.isConnected()) {
            //showToast("Please connect before retry again");
            return;
        }

        try {
            //Set
            IMqttToken token = mqtt.subscribe(topic, 0);
            //Check result
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Subscribed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribed");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribe failed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribe error!");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            //showToast(e.getMessage());
        }
    }

    public void ConfereSeq(String eAmaisDoisAtuad, String eAmenosDoisAtuad, String eBmaisDoisAtuad, String eBmenosDoisAtuad, String eKDoisAtuad, String sensorADoisAtuad, String sensorBDoisAtuad) {

        final String broker = getIntent().getStringExtra("MQTT_BROKER");
        final String usuario = getIntent().getStringExtra("MQTT_USUARIO");
        final String senha = getIntent().getStringExtra("MQTT_SENHA");
        final String id = mqtt.getClientId();

        // Action
        if (TextUtils.isEmpty(eAmaisDoisAtuad) || TextUtils.isEmpty(eAmenosDoisAtuad) || TextUtils.isEmpty(eBmaisDoisAtuad) || TextUtils.isEmpty(eBmenosDoisAtuad)) {
            showToast("Preencha os campos necessários!");
            return;
        }
        // Conexão Broker
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }
        // Conexões ESP
        if (msgstatusSensDoisAtuad == null) {
            showToast("Realizar conexão ESP32 SENSORES!");
            return;
        }
        if (msgstatusValvADoisAtuad == null) {
            showToast("Realizar conexão ESP32 VÁLVULA A!");
            return;
        }
        if (msgstatusValvBDoisAtuad == null) {
            showToast("Realizar conexão ESP32 VÁLVULA B!");
            return;
        }

        eAmaisDoisAtuad = eAmaisDoisAtuad.trim();
        eAmenosDoisAtuad = eAmenosDoisAtuad.trim();
        eBmaisDoisAtuad = eBmaisDoisAtuad.trim();
        eBmenosDoisAtuad = eBmenosDoisAtuad.trim();
        eKDoisAtuad = eKDoisAtuad.trim();

        //Sequência 1 - A+ B+ A- B- : A+ = b0.S ; A- = b1 ; B+ = a1 ; B- = a0
        if ((eAmaisDoisAtuad.equalsIgnoreCase("b0.S") || (eAmaisDoisAtuad.equalsIgnoreCase("S.b0")) || (eAmaisDoisAtuad.equalsIgnoreCase("b0S")) || (eAmaisDoisAtuad.equalsIgnoreCase("Sb0"))) && (eAmenosDoisAtuad.equalsIgnoreCase("b1")) && (eBmaisDoisAtuad.equalsIgnoreCase("a1")) && (eBmenosDoisAtuad.equalsIgnoreCase("a0"))) {
            if (sensorADoisAtuad == null) {
                showToast("Subscrever estado Atuador A");
                return;
            }
            if (sensorBDoisAtuad == null) {
                showToast("Subscrever estado Atuador B");
                return;
            }
            // Ajustando posição dos atuadores
            if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+A-B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishAmenos();
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+A-B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                publishAmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+A-B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+A-B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            }
        }
        // Sequência 2 - A+ B+ B- A- : A+ = not.A- ; A- = KNA.b0 ; B+ = a1.KNF ; B- = not.B+ ; K = (b1+KNA).not(a0) Ā ā
        if ((eAmaisDoisAtuad.equalsIgnoreCase("not A-") || eAmaisDoisAtuad.equalsIgnoreCase("not.A-") || eAmaisDoisAtuad.equalsIgnoreCase("notA-") || eAmaisDoisAtuad.equalsIgnoreCase("not(A-)")) && (eAmenosDoisAtuad.equalsIgnoreCase("KNA.b0") || eAmenosDoisAtuad.equalsIgnoreCase("KNAb0") || eAmenosDoisAtuad.equalsIgnoreCase("b0.KNA") || eAmenosDoisAtuad.equalsIgnoreCase("b0KNA")) && (eBmaisDoisAtuad.equalsIgnoreCase("a1.KNF") || eBmaisDoisAtuad.equalsIgnoreCase("a1KNF") || eBmaisDoisAtuad.equalsIgnoreCase("KNF.a1") || eBmaisDoisAtuad.equalsIgnoreCase("KNFa1")) && (eBmenosDoisAtuad.equalsIgnoreCase("not.B+") || eBmenosDoisAtuad.equalsIgnoreCase("notB+") || eBmenosDoisAtuad.equalsIgnoreCase("not B+") || eBmenosDoisAtuad.equalsIgnoreCase("not(B+)")) && (eKDoisAtuad.equalsIgnoreCase("(b1+KNA).not(a0)") || eKDoisAtuad.equalsIgnoreCase("(b1+KNA)not(a0)") || eKDoisAtuad.equalsIgnoreCase("(b1+KNA).not.a0") || eKDoisAtuad.equalsIgnoreCase("(b1+KNA).not a0") || eKDoisAtuad.equalsIgnoreCase("(KNA+b1).not(a0)") || eKDoisAtuad.equalsIgnoreCase("(KNA+b1)not(a0)") || eKDoisAtuad.equalsIgnoreCase("(KNA+b1).not.a0") || eKDoisAtuad.equalsIgnoreCase("(KNA+b1).not a0") || eKDoisAtuad.equalsIgnoreCase("(b1 + KNA).not(a0)") || eKDoisAtuad.equalsIgnoreCase("(KNA + b1).not(a0)"))) {
            if (sensorADoisAtuad == null) {
                showToast("Subscrever estado Atuador A");
                return;
            }
            if (sensorBDoisAtuad == null) {
                showToast("Subscrever estado Atuador B");
                return;
            }

            // Ajustando posição dos atuadores
            if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+B-A-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishAmenos();
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+B-A-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                publishAmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+B-A-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            } else if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+B+B-A-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
                return;
            }
        }
        //Sequência 3 - A+ A- B+ B- : A+ = KNF.b0 ; A- = not(A+) ; B+ = KNA.a0 ; B- = not(B+) ; K = (KNA+a1).not(b1)
        if ((eAmaisDoisAtuad.equalsIgnoreCase("KNF.b0") || (eAmaisDoisAtuad.equalsIgnoreCase("KNFb0")) || (eAmaisDoisAtuad.equalsIgnoreCase("b0.KNF")) || (eAmaisDoisAtuad.equalsIgnoreCase("b0KNF"))) && ((eAmenosDoisAtuad.equalsIgnoreCase("not(A+)")) || (eAmenosDoisAtuad.equalsIgnoreCase("not.A+")) || (eAmenosDoisAtuad.equalsIgnoreCase("not A+")) || (eAmenosDoisAtuad.equalsIgnoreCase("notA+"))) && ((eBmaisDoisAtuad.equalsIgnoreCase("KNA.a0")) || (eBmaisDoisAtuad.equalsIgnoreCase("KNAa0")) || (eBmaisDoisAtuad.equalsIgnoreCase("a0.KNA")) || (eBmaisDoisAtuad.equalsIgnoreCase("a0KNA"))) && ((eBmenosDoisAtuad.equalsIgnoreCase("not(B+)")) || (eBmenosDoisAtuad.equalsIgnoreCase("notB+")) || (eBmenosDoisAtuad.equalsIgnoreCase("not.B+")) || (eBmenosDoisAtuad.equalsIgnoreCase("not B+"))) && (eKDoisAtuad.equalsIgnoreCase("(KNA+a1).not(b1)") || eKDoisAtuad.equalsIgnoreCase("(a1+KNA).not(b1)") || eKDoisAtuad.equalsIgnoreCase("(KNA+a1)not(b1)") || eKDoisAtuad.equalsIgnoreCase("(a1+KNA)not(b1)") || eKDoisAtuad.equalsIgnoreCase("(KNA+a1)not.b1") || eKDoisAtuad.equalsIgnoreCase("(a1+KNA)not.b1") || eKDoisAtuad.equalsIgnoreCase("(KNA+a1)notb1") || eKDoisAtuad.equalsIgnoreCase("(a1+KNA)notb1"))) {
            if (sensorADoisAtuad == null) {
                showToast("Subscrever estado Atuador A");
                return;
            }
            if (sensorBDoisAtuad == null) {
                showToast("Subscrever estado Atuador B");
                return;
            }
            // Ajustando posição dos atuadores
            if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+A-B+B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Recuado"))) {
                publishAmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+A-B+B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
            } else if ((sensorADoisAtuad.equals("Atuador A Recuado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+A-B+B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
            } else if ((sensorADoisAtuad.equals("Atuador A Avançado")) && (sensorBDoisAtuad.equals("Atuador B Avançado"))) {
                publishAmenos();
                publishBmenos();
                // Crie um Intent para iniciar StartDoisAtuad
                Intent TelaStartDoisAtuad = new Intent(DoisAtuad.this, StartDoisAtuad.class);
                TelaStartDoisAtuad.putExtra("MQTTSEQUENCIA", "A+A-B+B-");
                TelaStartDoisAtuad.putExtra("MQTTBROKER", broker);
                TelaStartDoisAtuad.putExtra("MQTTUSUARIO", usuario);
                TelaStartDoisAtuad.putExtra("MQTTSENHA", senha);
                TelaStartDoisAtuad.putExtra("MQTTID", id);
                // Inicie a DashTresAtuad com o Intent
                startActivity(TelaStartDoisAtuad);
            }

        } else {
            showToast("Sequência não cadastrada!");
        }
    }

    public void publishAmais() {
        String topic = "/comando/valvA";
        String payload = "1"; // Avança o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmenos() {
        String topic = "/comando/valvA";
        String payload = "0"; // Recua o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmais() {
        String topic = "/comando/valvB";
        String payload = "1"; // Avança o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmenos() {
        String topic = "/comando/valvB";
        String payload = "0"; // Recua o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}