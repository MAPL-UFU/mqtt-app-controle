package com.somsakelect.android.mqttcontrolapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private RadioButton localLEM_rb, /* localMAPL_rb, */ nuvemShiftr_rb, nuvemHiveMQ_rb, doisAtuad_rb, tresAtuad_rb, controle_rb, comando_rb, dashboard_rb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Thread.sleep(1000); // Delay de um segundo para o Splash manter ativo na tela
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_main);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); // Iniciar no modo tela cheia

        localLEM_rb = findViewById(R.id.localLEM_rb);
        /* localMAPL_rb = findViewById(R.id.localMAPL_rb); */
        nuvemShiftr_rb = findViewById(R.id.nuvemShiftr_rb);
        nuvemHiveMQ_rb = findViewById(R.id.nuvemHiveMQ_rb);
        doisAtuad_rb = findViewById(R.id.doisAtuad_rb);
        tresAtuad_rb = findViewById(R.id.tresAtuad_rb);
        controle_rb = findViewById(R.id.controle_rb);
        comando_rb = findViewById(R.id.comando_rb);
        dashboard_rb = findViewById(R.id.dashboard_rb);

        // Botão Sair
        findViewById(R.id.exit_button).setOnClickListener(v -> finishAffinity());

        //Botão Confirmar
        findViewById(R.id.confirm_button).setOnClickListener(v -> {
            /* if (localMAPL_rb.isChecked() && doisAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar DoisAtuad
                Intent localMAPL_DoisAtuad = new Intent(MainActivity.this, DoisAtuad.class);
                localMAPL_DoisAtuad.putExtra("MQTT_BROKER", "192.168.100.122");
                localMAPL_DoisAtuad.putExtra("MQTT_USUARIO", "localufumapl");
                localMAPL_DoisAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@M4PL");
                // Inicie a DoisAtuad com o Intent
                startActivity(localMAPL_DoisAtuad);
            } else if (localMAPL_rb.isChecked() && doisAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashDoisAtuad
                Intent localMAPL_DashDoisAtuad = new Intent(MainActivity.this, DashDoisAtuad.class);
                localMAPL_DashDoisAtuad.putExtra("MQTT_BROKER", "192.168.100.122");
                localMAPL_DashDoisAtuad.putExtra("MQTT_USUARIO", "localufumapl");
                localMAPL_DashDoisAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@M4PL");
                // Inicie a DashDoisAtuad com o Intent
                startActivity(localMAPL_DashDoisAtuad);
            } else */ if (localLEM_rb.isChecked() && doisAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar DoisAtuad
                Intent localLEM_DoisAtuad = new Intent(MainActivity.this, DoisAtuad.class);
                localLEM_DoisAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_DoisAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_DoisAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a DoisAtuad com o Intent
                startActivity(localLEM_DoisAtuad);
            } else if (localLEM_rb.isChecked() && doisAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoDoisAtuad
                Intent localLEM_ComandoDoisAtuad = new Intent(MainActivity.this, ComandoDoisAtuad.class);
                localLEM_ComandoDoisAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_ComandoDoisAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_ComandoDoisAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a ComandoDoisAtuad com o Intent
                startActivity(localLEM_ComandoDoisAtuad);
            } else if (localLEM_rb.isChecked() && doisAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashDoisAtuad
                Intent localLEM_DashDoisAtuad = new Intent(MainActivity.this, DashDoisAtuad.class);
                localLEM_DashDoisAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_DashDoisAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_DashDoisAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a DashDoisAtuad com o Intent
                startActivity(localLEM_DashDoisAtuad);
            } else if (nuvemShiftr_rb.isChecked() && doisAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar DoisAtuad
                Intent nuvemShiftr_DoisAtuad = new Intent(MainActivity.this, DoisAtuad.class);
                nuvemShiftr_DoisAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_DoisAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_DoisAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a DoisAtuad com o Intent
                startActivity(nuvemShiftr_DoisAtuad);
            } else if (nuvemShiftr_rb.isChecked() && doisAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoDoisAtuad
                Intent nuvemShiftr_ComandoDoisAtuad = new Intent(MainActivity.this, ComandoDoisAtuad.class);
                nuvemShiftr_ComandoDoisAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_ComandoDoisAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_ComandoDoisAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a ComandoDoisAtuad com o Intent
                startActivity(nuvemShiftr_ComandoDoisAtuad);
            } else if (nuvemShiftr_rb.isChecked() && doisAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashDoisAtuad
                Intent nuvemShiftr_DashDoisAtuad = new Intent(MainActivity.this, DashDoisAtuad.class);
                nuvemShiftr_DashDoisAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_DashDoisAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_DashDoisAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a DashDoisAtuad com o Intent
                startActivity(nuvemShiftr_DashDoisAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && doisAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar DoisAtuad
                Intent nuvemHiveMQ_DoisAtuad = new Intent(MainActivity.this, DoisAtuad.class);
                nuvemHiveMQ_DoisAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_DoisAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_DoisAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a DoisAtuad com o Intent
                startActivity(nuvemHiveMQ_DoisAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && doisAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoDoisAtuad
                Intent nuvemHiveMQ_ComandoDoisAtuad = new Intent(MainActivity.this, ComandoDoisAtuad.class);
                nuvemHiveMQ_ComandoDoisAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_ComandoDoisAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_ComandoDoisAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a ComandoDoisAtuad com o Intent
                startActivity(nuvemHiveMQ_ComandoDoisAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && doisAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashDoisAtuad
                Intent nuvemHiveMQ_DashDoisAtuad = new Intent(MainActivity.this, DashDoisAtuad.class);
                nuvemHiveMQ_DashDoisAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_DashDoisAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_DashDoisAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a DashDoisAtuad com o Intent
                startActivity(nuvemHiveMQ_DashDoisAtuad);
            } /* else if (localMAPL_rb.isChecked() && tresAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar TresAtuad
                Intent localMAPL_TresAtuad = new Intent(MainActivity.this, TresAtuad.class);
                localMAPL_TresAtuad.putExtra("MQTT_BROKER", "192.168.100.122");
                localMAPL_TresAtuad.putExtra("MQTT_USUARIO", "localufumapl");
                localMAPL_TresAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@M4PL");
                // Inicie a TresAtuad com o Intent
                startActivity(localMAPL_TresAtuad);
            } else if (localMAPL_rb.isChecked() && tresAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashTresAtuad
                Intent localMAPL_DashTresAtuad = new Intent(MainActivity.this, DashTresAtuad.class);
                localMAPL_DashTresAtuad.putExtra("MQTT_BROKER", "192.168.100.122");
                localMAPL_DashTresAtuad.putExtra("MQTT_USUARIO", "localufumapl");
                localMAPL_DashTresAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@M4PL");
                // Inicie a DashTresAtuad com o Intent
                startActivity(localMAPL_DashTresAtuad);
            } */ else if (localLEM_rb.isChecked() && tresAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar TresAtuad
                Intent localLEM_TresAtuad = new Intent(MainActivity.this, TresAtuad.class);
                localLEM_TresAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_TresAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_TresAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a TresAtuad com o Intent
                startActivity(localLEM_TresAtuad);
            } else if (localLEM_rb.isChecked() && tresAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoTresAtuad
                Intent localLEM_ComandoTresAtuad = new Intent(MainActivity.this, ComandoTresAtuad.class);
                localLEM_ComandoTresAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_ComandoTresAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_ComandoTresAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a ComandoTresAtuad com o Intent
                startActivity(localLEM_ComandoTresAtuad);
            } else if (localLEM_rb.isChecked() && tresAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashTresAtuad
                Intent localLEM_DashTresAtuad = new Intent(MainActivity.this, DashTresAtuad.class);
                localLEM_DashTresAtuad.putExtra("MQTT_BROKER", "10.32.80.12");
                localLEM_DashTresAtuad.putExtra("MQTT_USUARIO", "localufulem");
                localLEM_DashTresAtuad.putExtra("MQTT_SENHA", "r4spb3rryp!@L3M");
                // Inicie a DashTresAtuad com o Intent
                startActivity(localLEM_DashTresAtuad);
            } else if (nuvemShiftr_rb.isChecked() && tresAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar TresAtuad
                Intent nuvemShiftr_TresAtuad = new Intent(MainActivity.this, TresAtuad.class);
                nuvemShiftr_TresAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_TresAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_TresAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a TresAtuad com o Intent
                startActivity(nuvemShiftr_TresAtuad);
            } else if (nuvemShiftr_rb.isChecked() && tresAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoTresAtuad
                Intent nuvemShiftr_ComandoTresAtuad = new Intent(MainActivity.this, ComandoTresAtuad.class);
                nuvemShiftr_ComandoTresAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_ComandoTresAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_ComandoTresAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a ComandoTresAtuad com o Intent
                startActivity(nuvemShiftr_ComandoTresAtuad);
            } else if (nuvemShiftr_rb.isChecked() && tresAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashTresAtuad
                Intent nuvemShiftr_DashTresAtuad = new Intent(MainActivity.this, DashTresAtuad.class);
                nuvemShiftr_DashTresAtuad.putExtra("MQTT_BROKER", "ufumapl.cloud.shiftr.io");
                nuvemShiftr_DashTresAtuad.putExtra("MQTT_USUARIO", "ufumapl");
                nuvemShiftr_DashTresAtuad.putExtra("MQTT_SENHA", "p0dy0EfwVhUSzXlC");
                // Inicie a DashTresAtuad com o Intent
                startActivity(nuvemShiftr_DashTresAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && tresAtuad_rb.isChecked() && controle_rb.isChecked()) {
                // Crie um Intent para iniciar TresAtuad
                Intent nuvemHiveMQ_TresAtuad = new Intent(MainActivity.this, TresAtuad.class);
                nuvemHiveMQ_TresAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_TresAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_TresAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a TresAtuad com o Intent
                startActivity(nuvemHiveMQ_TresAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && tresAtuad_rb.isChecked() && comando_rb.isChecked()) {
                // Crie um Intent para iniciar ComandoTresAtuad
                Intent nuvemHiveMQ_ComandoTresAtuad = new Intent(MainActivity.this, ComandoTresAtuad.class);
                nuvemHiveMQ_ComandoTresAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_ComandoTresAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_ComandoTresAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a ComandoTresAtuad com o Intent
                startActivity(nuvemHiveMQ_ComandoTresAtuad);
            } else if (nuvemHiveMQ_rb.isChecked() && tresAtuad_rb.isChecked() && dashboard_rb.isChecked()) {
                // Crie um Intent para iniciar DashTresAtuad
                Intent nuvemHiveMQ_DashTresAtuad = new Intent(MainActivity.this, DashTresAtuad.class);
                nuvemHiveMQ_DashTresAtuad.putExtra("MQTT_BROKER", "broker.hivemq.com");
                nuvemHiveMQ_DashTresAtuad.putExtra("MQTT_USUARIO", "");
                nuvemHiveMQ_DashTresAtuad.putExtra("MQTT_SENHA", "");
                // Inicie a DashTresAtuad com o Intent
                startActivity(nuvemHiveMQ_DashTresAtuad);
            } else {
                // Informe ao usuário que ele deve selecionar uma opção de cada grupo
                showToast("Por favor, selecione uma opção de cada grupo!");
            }
        });
    }
    // Função para habilitar o Toast personalizado
    public void showToast(String message) {
        ViewGroup view = findViewById(R.id.container_toast);
        View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

        TextView txtMessage = v.findViewById(R.id.txt_toast);
        txtMessage.setText(message);

        Toast toast = new Toast(this);
        toast.setView(v);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
}