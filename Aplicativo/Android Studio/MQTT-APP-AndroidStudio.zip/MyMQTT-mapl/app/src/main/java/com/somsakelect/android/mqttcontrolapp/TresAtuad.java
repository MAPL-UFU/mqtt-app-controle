package com.somsakelect.android.mqttcontrolapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.somsakelect.android.mqtt.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class TresAtuad extends AppCompatActivity {
    private MqttAndroidClient mqtt;

    private TextView statusConexaoTresAtuad;
    private EditText eAmaisTresAtuad, eAmenosTresAtuad, eBmaisTresAtuad, eBmenosTresAtuad, eCmaisTresAtuad, eCmenosTresAtuad, eKTresAtuad;
    private String msgstatusSensTresAtuad, msgstatusValvATresAtuad, msgstatusValvBTresAtuad, msgstatusValvCTresAtuad, sensorATresAtuad, sensorBTresAtuad, sensorCTresAtuad;
    private LinearLayout btnConectarTA;
    private static final String TAG = "TresAtuad";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_MyMQTT); // App inicia com o tema Splash. Aqui altera para o tema principal
        setContentView(R.layout.activity_tres_atuad);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Recupere o valor da string (HOST) do Intent
        final String MQTT_HOST = getIntent().getStringExtra("MQTT_BROKER");
        final int MQTT_PORT = 1883;
        final String MQTT_URL = "tcp://" + MQTT_HOST + ":" + MQTT_PORT;
        final String MQTT_ID = MqttClient.generateClientId();

        statusConexaoTresAtuad = findViewById(R.id.tv_statusConexaoTresAtuad);
        eAmaisTresAtuad = findViewById(R.id.AmaisTresAtuad_e);
        eAmenosTresAtuad = findViewById(R.id.AmenosTresAtuad_e);
        eBmaisTresAtuad = findViewById(R.id.BmaisTresAtuad_e);
        eBmenosTresAtuad = findViewById(R.id.BmenosTresAtuad_e);
        eCmaisTresAtuad = findViewById(R.id.CmaisTresAtuad_e);
        eCmenosTresAtuad = findViewById(R.id.CmenosTresAtuad_e);
        eKTresAtuad = findViewById(R.id.KTresAtuad_e);
        btnConectarTA = (LinearLayout) findViewById(R.id.ll_btnConectarTA);

        //MQTT
        mqtt = new MqttAndroidClient(this, MQTT_URL, MQTT_ID);
        mqtt.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.w(TAG, "Reconexão MQTT..." + reconnect);
                statusConexaoTresAtuad.setText(reconnect ? "Reconectando..." : "Conectado!");
                if (mqtt.isConnected()) {
                    String tsx = "CONECTADO!";
                    statusConexaoTresAtuad.setText(tsx);
                    btnConectarTA.setVisibility(View.INVISIBLE);
                    subscribe("/status/espSensores"); // Recebe o status do ESP32 dos sensores de fim de curso
                    subscribe("/status/espValvA"); // Recebe o status do ESP32 da válvula A
                    subscribe("/status/espValvB"); // Recebe o status do ESP32 da válvula B
                    subscribe("/status/espValvC"); // Recebe o status do ESP32 da válvula C
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                if (cause != null) {
                    Log.e(TAG, "Conexão MQTT perdida..." + cause.getMessage());
                    String st = "Conexão perdida! " + cause.getMessage();
                    statusConexaoTresAtuad.setText(st);
                    btnConectarTA.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                if (topic.equals("/status/espSensores")) {
                    //String statusValvA;
                    msgstatusSensTresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espSensores", msgstatusSensTresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/status/espValvA")) {
                    //String statusValvB;
                    msgstatusValvATresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espValvA", msgstatusValvATresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/status/espValvB")) {
                    //String statusValvB;
                    msgstatusValvBTresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espValvB", msgstatusValvBTresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/status/espValvC")) {
                    //String statusValvC;
                    msgstatusValvCTresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/status/espValvC", msgstatusValvCTresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorA")) {
                    //String sensorA;
                    sensorATresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorA", sensorATresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorB")) {
                    //String sensorB;
                    sensorBTresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorB", sensorBTresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
                if (topic.equals("/estado/atuadorC")) {
                    //String sensorC;
                    sensorCTresAtuad = message.toString();
                    String log = String.format("MQTT RX [%s]: %s", "/estado/atuadorC", sensorCTresAtuad);
                    Log.w(TAG, log);
                    //Debug
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.w(TAG, "Publish success...");
                //showToast("Publish success!");
            }
        });

        //Botão Conectar
        findViewById(R.id.conBrokerTresAtuad_btn).setOnClickListener(v -> connectMQTT());

        //Botão Voltar
        findViewById(R.id.voltarTresAtuad_btn).setOnClickListener(v -> {
            // Crie um Intent para iniciar MainActivity
            Intent mqtt_setup = new Intent(TresAtuad.this, MainActivity.class);
            disconnectMQTT();
            // Inicie a TresAtuad com o Intent
            startActivity(mqtt_setup);
        });

        //Botão Confirmar
        findViewById(R.id.confirmTresAtuad_btn).setOnClickListener(v -> ConfereSeq(getEnter(eAmaisTresAtuad), getEnter(eAmenosTresAtuad), getEnter(eBmaisTresAtuad), getEnter(eBmenosTresAtuad), getEnter(eCmaisTresAtuad), getEnter(eCmenosTresAtuad), getEnter(eKTresAtuad), sensorATresAtuad, sensorBTresAtuad, sensorCTresAtuad));

        //Try connect
        connectMQTT();
    }
    // Função para desabilitar "Voltar" via botão do hardware
    @Override
    public void onBackPressed() {
        // Não faz nada ao clicar no botão voltar do hardware
    }
    // Funções para ativar modo tela cheia ao iniciar o aplicativo
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    public void showToast(String message) {
        ViewGroup view = findViewById(R.id.container_toast);
        View v = getLayoutInflater().inflate(R.layout.custom_toast, view);

        TextView txtMessage = v.findViewById(R.id.txt_toast);
        txtMessage.setText(message);

        Toast toast = new Toast(this);
        toast.setView(v);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    // Função para salvar os campos de input (EditText) como string
    private String getEnter(EditText e) {
        return e.getText().toString();
    }

    private void connectMQTT() {
        if (mqtt.isConnected()) {
            showToast("Broker já conectado!");
            statusConexaoTresAtuad.setText(R.string.conectado);
            btnConectarTA.setVisibility(View.INVISIBLE);
            return;
        }

        Log.w(TAG, "Conectando ao broker MQTT...");
        statusConexaoTresAtuad.setText(R.string.conectando);

        // Recupere o valor da string (USERNAME e PASSWORD) do Intent
        final String MQTT_USERNAME = getIntent().getStringExtra("MQTT_USUARIO");
        final String MQTT_PASSWORD = getIntent().getStringExtra("MQTT_SENHA");

        //Set option
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(MQTT_USERNAME);
        options.setPassword(MQTT_PASSWORD.toCharArray());
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        try {
            IMqttToken token = mqtt.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Connect success!");
                    //Subscribe
                    subscribe("/status/espSensores"); // Recebe o status do ESP32 dos sensores de fim de curso
                    subscribe("/status/espValvA"); // Recebe o status do ESP32 da válvula A
                    subscribe("/status/espValvB"); // Recebe o status do ESP32 da válvula B
                    subscribe("/status/espValvC"); // Recebe o status do ESP32 da válvula C
                    subscribe("/estado/atuadorA"); // Recebe o estado (avançado ou recuado) do atuador A
                    subscribe("/estado/atuadorB"); // Recebe o estado do atuador B
                    subscribe("/estado/atuadorC"); // Recebe o estado do atuador C
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error..." + exception.getMessage());
                    String tsx = "Falha na conexão... " + exception.getMessage();
                    statusConexaoTresAtuad.setText(tsx);
                    btnConectarTA.setVisibility(View.VISIBLE);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            String tsx = "Connect MqttException: " + e.getMessage();
            statusConexaoTresAtuad.setText(tsx);
            btnConectarTA.setVisibility(View.VISIBLE);
        }
    }

    private void disconnectMQTT() {
        Log.d(TAG, "Disconnecting MQTT server...");
        try {
            IMqttToken token = mqtt.disconnect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Disconnect success...");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Disconnect failed...");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "Error..." + e.getMessage());
        }
    }

    private void subscribe(@NonNull String topic) {
        //Connect
        if (!mqtt.isConnected()) {
            //showToast("Please connect before retry again");
            return;
        }

        try {
            //Set
            IMqttToken token = mqtt.subscribe(topic, 0);
            //Check result
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.w(TAG, "Subscribed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribed");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Subscribe failed..."
                            + Arrays.toString(asyncActionToken.getTopics()));
                    //showToast("Subscribe error!");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();

            //showToast(e.getMessage());
        }
    }

    public void ConfereSeq(String eAmaisTresAtuad, String eAmenosTresAtuad, String eBmaisTresAtuad, String eBmenosTresAtuad, String eCmaisTresAtuad, String eCmenosTresAtuad, String eKTresAtuad, String sensorATresAtuad, String sensorBTresAtuad, String sensorCTresAtuad) {

        final String brokerTA = getIntent().getStringExtra("MQTT_BROKER");
        final String usuarioTA = getIntent().getStringExtra("MQTT_USUARIO");
        final String senhaTA = getIntent().getStringExtra("MQTT_SENHA");
        final String idTA = mqtt.getClientId();

        // Action
        if (TextUtils.isEmpty(eAmaisTresAtuad) || TextUtils.isEmpty(eAmenosTresAtuad) || TextUtils.isEmpty(eBmaisTresAtuad) || TextUtils.isEmpty(eBmenosTresAtuad) || TextUtils.isEmpty(eCmaisTresAtuad) || TextUtils.isEmpty(eCmenosTresAtuad)) {
            showToast("Preencha os campos necessários!");
            return;
        }
        // Conexão Broker
        if (!mqtt.isConnected()) {
            showToast("Conecte-se ao broker e tente novamente!");
            return;
        }
        // Conexões ESP
        if (msgstatusSensTresAtuad == null) {
            showToast("Realizar conexão ESP32 SENSORES!");
            return;
        }
        if (msgstatusValvATresAtuad == null) {
            showToast("Realizar conexão ESP32 VÁLVULA A!");
            return;
        }
        if (msgstatusValvBTresAtuad == null) {
            showToast("Realizar conexão ESP32 VÁLVULA B!");
            return;
        }
        if (msgstatusValvCTresAtuad == null) {
            showToast("Realizar conexão ESP32 VÁLVULA C!");
            return;
        }

        eAmaisTresAtuad = eAmaisTresAtuad.trim();
        eAmenosTresAtuad = eAmenosTresAtuad.trim();
        eBmaisTresAtuad = eBmaisTresAtuad.trim();
        eBmenosTresAtuad = eBmenosTresAtuad.trim();
        eCmaisTresAtuad = eCmaisTresAtuad.trim();
        eCmenosTresAtuad = eCmenosTresAtuad.trim();
        eKTresAtuad = eKTresAtuad.trim();

        // Sequência A+ B+ C+ C- B- A- : A+ = S ; A- = b0.KNF ; B+ = a1.KNA ; B- = c0.KNF ; C+ = b1.KNA ; C- = KNF+not.b1 ; K = (a0+KNA).not.c1
        if ((eAmaisTresAtuad.equalsIgnoreCase("BT") || eAmaisTresAtuad.equalsIgnoreCase("S")) && (eAmenosTresAtuad.equalsIgnoreCase("KNF.b0") || eAmenosTresAtuad.equalsIgnoreCase("b0.KNF") || eAmenosTresAtuad.equalsIgnoreCase("b0KNF") || eAmenosTresAtuad.equalsIgnoreCase("KNFb0")) && (eBmaisTresAtuad.equalsIgnoreCase("a1.KNA") || eBmaisTresAtuad.equalsIgnoreCase("KNA.a1") || eBmaisTresAtuad.equalsIgnoreCase("a1KNA") || eBmaisTresAtuad.equalsIgnoreCase("KNAa1")) && (eBmenosTresAtuad.equalsIgnoreCase("c0.KNF") || eBmenosTresAtuad.equalsIgnoreCase("KNF.c0") || eBmenosTresAtuad.equalsIgnoreCase("KNFc0") || eBmenosTresAtuad.equalsIgnoreCase("c0KNF")) && (eCmaisTresAtuad.equalsIgnoreCase("b1.KNA") || eCmaisTresAtuad.equalsIgnoreCase("KNA.b1") || eCmaisTresAtuad.equalsIgnoreCase("KNAb1") || eCmaisTresAtuad.equalsIgnoreCase("b1KNA")) && (eCmenosTresAtuad.equalsIgnoreCase("KNF + not(b1)") || eCmenosTresAtuad.equalsIgnoreCase("KNF+not(b1)") || eCmenosTresAtuad.equalsIgnoreCase("KNF+notb1") || eCmenosTresAtuad.equalsIgnoreCase("KNF+not.b1")) && (eKTresAtuad.equalsIgnoreCase("(a0+KNA).not(c1)") || eKTresAtuad.equalsIgnoreCase("(KNA+a0).not(c1)") || eKTresAtuad.equalsIgnoreCase("(KNA+a0)not(c1)") || eKTresAtuad.equalsIgnoreCase("(a0+KNA)not(c1)") || eKTresAtuad.equalsIgnoreCase("(KNA+a0)notc1") || eKTresAtuad.equalsIgnoreCase("(a0+KNA)notc1"))) {
            if (sensorATresAtuad == null) {
                showToast("Subscrever estado Atuador A");
                return;
            }
            if (sensorBTresAtuad == null) {
                showToast("Subscrever estado Atuador B");
                return;
            }
            if (sensorCTresAtuad == null) {
                showToast("Subscrever estado Atuador C");
                return;
            }
            // Ajustando posição dos atuadores
            if ( (sensorATresAtuad.equals("Atuador A Recuado")) && (sensorBTresAtuad.equals("Atuador B Recuado")) && (sensorCTresAtuad.equals("Atuador C Recuado")) ) {
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Avançado")) && (sensorBTresAtuad.equals("Atuador B Avançado")) && (sensorCTresAtuad.equals("Atuador C Avançado")) ) {
                publishAmenos();
                publishBmenos();
                publishCmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Avançado")) && (sensorBTresAtuad.equals("Atuador B Recuado")) && (sensorCTresAtuad.equals("Atuador C Recuado")) ) {
                publishAmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Recuado")) && (sensorBTresAtuad.equals("Atuador B Avançado")) && (sensorCTresAtuad.equals("Atuador C Recuado")) ) {
                publishBmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Recuado")) && (sensorBTresAtuad.equals("Atuador B Recuado")) && (sensorCTresAtuad.equals("Atuador C Avançado")) ) {
                publishCmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Avançado")) && (sensorBTresAtuad.equals("Atuador B Avançado")) && (sensorCTresAtuad.equals("Atuador C Recuado")) ) {
                publishAmenos();
                publishBmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Avançado")) && (sensorBTresAtuad.equals("Atuador B Recuado")) && (sensorCTresAtuad.equals("Atuador C Avançado")) ) {
                publishAmenos();
                publishCmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            } else if ( (sensorATresAtuad.equals("Atuador A Recuado")) && (sensorBTresAtuad.equals("Atuador B Avançado")) && (sensorCTresAtuad.equals("Atuador C Avançado")) ) {
                publishBmenos();
                publishCmenos();
                // Crie um Intent para iniciar TelaStartTresAtuad
                Intent TelaStartTresAtuad = new Intent(TresAtuad.this, StartTresAtuad.class);
                TelaStartTresAtuad.putExtra("MQTTSEQUENCIATA", "A+B+C+C-B-A-");
                TelaStartTresAtuad.putExtra("MQTTBROKERTA", brokerTA);
                TelaStartTresAtuad.putExtra("MQTTUSUARIOTA", usuarioTA);
                TelaStartTresAtuad.putExtra("MQTTSENHATA", senhaTA);
                TelaStartTresAtuad.putExtra("MQTTIDTA", idTA);
                // Inicie a TelaStartTresAtuad com o Intent
                startActivity(TelaStartTresAtuad);
            }

        } else {
            showToast("Sequência não cadastrada!");
        }
    }

    public void publishAmais() {
        String topic = "/comando/valvA";
        String payload = "1"; // Avança o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishAmenos() {
        String topic = "/comando/valvA";
        String payload = "0"; // Recua o atuador A
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmais() {
        String topic = "/comando/valvB";
        String payload = "1"; // Avança o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishBmenos() {
        String topic = "/comando/valvB";
        String payload = "0"; // Recua o atuador B
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmais() {
        String topic = "/comando/valvC";
        String payload = "1"; // Avança o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publishCmenos() {
        String topic = "/comando/valvC";
        String payload = "0"; // Recua o atuador C
        try {
            byte[] encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            mqtt.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}